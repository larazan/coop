import { CLEAR_EXPIRED_SLOT } from '../slots/actions';

export const SEVERITY = {
  INFO: 'INFO',
  MINOR: 'MINOR',
  MAJOR: 'MAJOR',
  CRITICAL: 'CRITICAL'
};

export const ERROR_RESOLUTIONS = {
  RELOAD: 'RELOAD',
  LINK: 'LINK',
  CLOSE: 'CLOSE'
};

export const ERROR_ADDRESS_POSTCODE_INLINE_VALIDATION_FAIL = {
  title: 'Please enter a correct postcode format',
  content: 'For example, M4 4BE.'
};

export const ERROR_ADDRESS_POSTCODE_LOOKUP_VALIDATION_FAIL = {
  title: 'Sorry, we were unable to find any addresses for your postcode',
  content: 'Please enter a different postcode.'
};

export const ERROR_ADDRESS_POSTCODE_LOOKUP_NO_RESULTS = {
  title: 'Sorry, we were unable to find any addresses for your postcode',
  content: 'Please enter a different postcode.',
  severity: SEVERITY.MINOR
};

export const ERROR_ADDRESS_POSTCODE_LOOKUP_FAIL = {
  title: 'Sorry, something went wrong',
  content: 'We couldn’t check for your postcode, please try again.',
  severity: SEVERITY.MINOR
};

export const ERROR_ADDRESS_NOT_IN_SERVICE_AREA = {
  title: 'Sorry, this service is currently unavailable in your area'
};

export const ERROR_FETCHING_CATEGORIES = {
  title: 'Sorry, something went wrong',
  content: 'We were not able to load navigation data right now. Please try reloading the page.',
  severity: SEVERITY.MAJOR,
  resolution: {
    type: ERROR_RESOLUTIONS.CLOSE,
    label: 'Try again'
  }
};

export const ERROR_FETCHING_PRODUCTS = {
  title: 'Sorry, something went wrong',
  content: 'We were not able to load products for this category. Try reloading the page.',
  severity: SEVERITY.MINOR
};

export const ERROR_FETCHING_PRODUCT_DETAILS = {
  title: 'Sorry, something went wrong',
  content: 'We were not able to load details for this product. Try reloading the page.',
  severity: SEVERITY.MINOR
};

export const ERROR_FETCH_USER_INFO = {
  content: 'Sorry, we could not fetch your customer information. Please try again later.',
  severity: SEVERITY.MINOR
};

export const ERROR_SAVE_USER_INFO = {
  content: 'Sorry, we could not save your customer information. Please try again later.',
  severity: SEVERITY.MINOR
};

export const ERROR_PLACE_ORDER_MISC = {
  title: 'Sorry, something went wrong',
  content: 'We could not place your order, please go back to checkout try again.',
  severity: SEVERITY.MAJOR,
  resolution: {
    type: ERROR_RESOLUTIONS.LINK,
    url: '/checkout',
    label: 'Try again'
  }
};

export const REGISTER_SUCCESS = {
  title: 'Account created',
  content:
    'Check your email and verify your account within 24 hours. If you have not received an email contact customer support',
  severity: SEVERITY.INFO
};

export const REGISTER_ERROR = {
  title: 'Sorry, something went wrong',
  content: 'We were unable to complete the registration process. Try again.',
  severity: SEVERITY.MINOR
};

export const AUTH_SUCCESS = {
  content: 'You are now signed in',
  severity: SEVERITY.MINOR
};

export const AUTH_FAILURE = {
  content: 'The email and password combination you used seem to be incorrect',
  severity: SEVERITY.MINOR
};

export const AUTH_FAILURE_UNVERIFIED_ACCOUNT_EXPIRED = {
  title: 'Unverified account',
  content:
    'Sorry, because you did not verify your account it’s been locked. Contact our customer support team to get it unlocked.',
  severity: SEVERITY.MINOR
};

export const GENERIC_ERROR = {
  title: 'Service temporarily down',
  content: 'Sorry, there seems to be a problem with our service. Please try again in a moment.',
  severity: SEVERITY.MINOR
};

export const EXPIRED_SLOT_NOTIFICATION = {
  id: CLEAR_EXPIRED_SLOT,
  content: 'Your slot reservation has expired. Choose a new slot before checking out.',
  severity: SEVERITY.MINOR
};
