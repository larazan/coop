import slotSaga from './operations';
import * as slotActions from './actions';
import reducer from './reducer';

export { slotActions, slotSaga };

export default reducer;
