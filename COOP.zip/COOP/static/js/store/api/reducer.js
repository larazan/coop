import { UPDATE_BASKET_SUCCESS } from '../basket/actions';
import { RESET_APP_STATE } from '../complete/actions';
import {
  PLACE_ORDER_FAILURE,
  PLACE_ORDER_FAILURE_SLOT,
  PLACE_ORDER_REQUEST,
  PLACE_ORDER_SUCCESS
} from '../order/actions';
import {
  FINALIZE_ORDER_FAILURE,
  FINALIZE_ORDER_SUCCESS,
  PAYMENT_CHECKOUT_SESSION_EXPIRED,
  PAYMENT_RESET_STATE,
  PAYMENT_SUBMIT_FORM
} from '../payment/actions';

export const initialState = {
  basket: {
    id: null,
    itemIds: {},
    itemsSnapshot: {},
    evaluate: {}
  },
  order: {
    orderNumber: null,
    visibleId: null,
    createdAt: null,
    confirmedPrice: 0,
    checkoutUrl: null,
    checkoutId: null,
    totalBreakdown: null,
    isOrderPlaced: null,
    isFetching: false
  },
  payment: {
    isFinalized: false,
    isSubmitted: false,
    status: null
  }
};

export const PAYMENT_SUCCESSFUL = 'PAYMENT_SUCCESSFUL';
export const PAYMENT_FAILED = 'PAYMENT_FAILED';

const storePlacedOrderDetails = (state, action) => {
  return { ...state, order: { ...action.payload, isFetching: false, isOrderPlaced: true } };
};

const storeBasketEvaluate = (state, { evaluate }) => ({
  ...state,
  basket: {
    ...state.basket,
    evaluate
  }
});

const expireCheckoutSession = state => {
  return {
    ...state,
    order: initialState.order,
    payment: { ...initialState.payment }
  };
};

const submitPaymentForm = state => ({
  ...state,
  payment: { ...state.payment, isSubmitted: true }
});

const resetPaymentState = state => ({ ...state, payment: initialState.payment });

const finalizeOrderSuccess = state => ({
  ...state,
  payment: {
    ...state.payment,
    isFinalized: true,
    status: PAYMENT_SUCCESSFUL
  }
});

const finalizeOrderFailure = state => ({
  ...state,
  payment: {
    ...state.payment,
    isFinalized: true,
    status: PAYMENT_FAILED
  }
});

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_BASKET_SUCCESS:
      return storeBasketEvaluate(state, action.payload);
    case PLACE_ORDER_REQUEST:
      return { ...state, order: { ...state.order, isFetching: true } };
    case PLACE_ORDER_FAILURE:
    case PLACE_ORDER_FAILURE_SLOT:
      return { ...state, order: { ...state.order, isFetching: false, isOrderPlaced: false } };
    case PLACE_ORDER_SUCCESS:
      return storePlacedOrderDetails(state, action);
    case PAYMENT_CHECKOUT_SESSION_EXPIRED:
      return expireCheckoutSession(state);
    case PAYMENT_SUBMIT_FORM:
      return submitPaymentForm(state);
    case PAYMENT_RESET_STATE:
      return resetPaymentState(state);
    case FINALIZE_ORDER_SUCCESS:
      return finalizeOrderSuccess(state);
    case FINALIZE_ORDER_FAILURE:
      return finalizeOrderFailure(state);
    case RESET_APP_STATE:
      return initialState;
    default:
      return state;
  }
};

export default reducer;
