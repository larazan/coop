import { call } from 'redux-saga/effects';
import { apis } from '../../api/dgApi';
import { isValidPostcode } from '../../utils/isValidPostcode';

export const errors = {
  postcodeFormat: 'Please enter a correct postcode format. For example, M4 4BE.',
  postcodeUnknown:
    'Sorry, we were unable to find any addresses for your postcode. Please enter a different postcode.',
  notInServiceArea: 'Sorry, you appear to be outside of our service area.',
  unhandled: 'Sorry, something went wrong. We couldn’t check for your postcode, please try again.'
};

export class PostcodeError extends Error {}

function* isPostcodeValid(postcode) {
  const isValid = yield call(isValidPostcode, postcode);
  if (!isValid) {
    throw new PostcodeError(errors.postcodeFormat);
  }
}

function* getCoordinatesFor(postcode) {
  const coordinates = yield call(apis.addressesCoordinatesRead, { postcode });
  if (!coordinates) {
    throw new PostcodeError(errors.postcodeUnknown);
  }
  return coordinates;
}

function* getStoresFor(coordinates) {
  return yield call(apis.addressesPlacesNearbyRead, {
    coordinates
  });
}

export function* getLocationInfoFor(postcode) {
  yield isPostcodeValid(postcode);

  const coordinates = yield getCoordinatesFor(postcode);

  const { collections, deliveries, storeId } = yield getStoresFor(coordinates);

  return {
    coordinates,
    collections,
    deliveries,
    storeId
  };
}

const inCollectionServiceArea = collections => collections.length > 0;

export function* isInCollectionServiceArea({ collections }) {
  const inArea = yield call(inCollectionServiceArea, collections);
  if (!inArea) {
    throw new PostcodeError(errors.notInServiceArea);
  }
}

const inDeliveryServiceArea = deliveries => deliveries.length > 0;

export function* isInDeliveryServiceArea({ deliveries }) {
  const inArea = yield call(inDeliveryServiceArea, deliveries);
  if (!inArea) {
    throw new PostcodeError(errors.notInServiceArea);
  }
}

export function* isInServiceArea({ collections, deliveries }) {
  const inCollectionArea = yield call(inCollectionServiceArea, collections);
  const inDeliveryArea = yield call(inDeliveryServiceArea, deliveries);

  if (!inCollectionArea && !inDeliveryArea) {
    throw new PostcodeError(errors.notInServiceArea);
  }
}
