import { filter, find, get, getOr, has, isEmpty, mapValues, size, sortBy, values } from 'lodash/fp';
import { createSelector } from 'reselect';
import formatPrice from '../../utils/formatPrice';
import { getBasketItemGtins, itemsInBasket } from '../basket/selectors';
import { getSelectedCategory } from '../categories/selectors';
import { getSearchProductsIds } from '../search/selectors';
import { toBool } from '../shared';
import getBasketItemQuantity from './utils/getBasketItemQuantity';

// TODO maybe use getProducts for all access to state.products?
export const getProducts = state => state.products;

export const isFetchingList = state => toBool(getProducts(state).isFetchingList);
export const isFetchingDetails = state => toBool(getProducts(state).isFetchingDetails);

export const getProductItems = state => getProducts(state).items;
export const getUnavailableProducts = state => getProducts(state).unavailable;

export const isAvailableInCurrentStore = (state, id) => {
  const available = getProductItems(state);
  const unavailable = getUnavailableProducts(state);

  return !has(id, unavailable) && has(id, available);
};

export const getProductById = (state, id) => {
  const isAvailable = isAvailableInCurrentStore(state, id);

  if (isAvailable) {
    const product = get(id, getProductItems(state));
    return { ...product, isAvailable };
  }

  const unavailableProduct = find({ id }, getUnavailableProducts(state));

  if (unavailableProduct) {
    return { ...unavailableProduct, isAvailable };
  }

  return null;
};

export const getProductsWithBasketQuantitySelector = () =>
  createSelector([itemsInBasket, getProductItems], (basketItems, products) =>
    values(
      mapValues(
        product => ({
          ...product,
          displayPrice: formatPrice(product.price),
          quantity: getBasketItemQuantity(basketItems, product.gtin)
        }),
        products
      )
    )
  );

export const productsOfCurrentCategory = () =>
  createSelector(
    [getProductsWithBasketQuantitySelector(), getSelectedCategory],
    (products, selectedCategoryId) =>
      filter(p => p.parentCategories.includes(selectedCategoryId), products)
  );

export const productsMatchingSearchTerm = () =>
  createSelector(
    [getProductsWithBasketQuantitySelector(), getSearchProductsIds],
    (products, searchProducts) => filter(p => searchProducts.includes(p.id), products)
  );

export const productsMatchingGtins = gtins =>
  createSelector([getProductsWithBasketQuantitySelector()], products =>
    sortBy(
      p => gtins.indexOf(p.gtin),
      filter(p => gtins.includes(p.gtin), products)
    )
  );

export const getBasketItems = () =>
  createSelector(
    getProductsWithBasketQuantitySelector(),
    filter(product => product.quantity > 0)
  );

export const productCount = selectorToCount =>
  createSelector(selectorToCount, products => size(products));

export const getNextPageForProductFetch = (state, key) => {
  const products = getProducts(state);
  return getOr(1, ['nextProductPage', key], products);
};

export const productCountByKey = (state, key) => {
  return getOr(0, key, getProducts(state).totalProductCountByCategory);
};

export const hasInfoForAllBasketItems = state => {
  const gtins = getBasketItemGtins(state);
  const products = productsMatchingGtins(gtins)(state);

  return gtins.length === products.length;
};

export const hasHitMaxProductQuantity = (state, id) => {
  const basketItems = itemsInBasket(state);
  const product = getOr({}, `products.items.${id}`, state);
  const quantity = getBasketItemQuantity(basketItems, product.gtin);

  if (isEmpty(product)) {
    return false;
  }

  return quantity >= product.maxQuantity;
};
