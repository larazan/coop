export const Pathnames = Object.freeze({
  home: '/',
  preSignIn: '/pre-sign-in',
  postSignIn: '/post-sign-in',
  signOut: '/sign-out'
});
