import { call, put, select, takeLatest } from 'redux-saga/effects';
import { apis } from '../../api/dgApi';
import { logError } from '../../utils/logError';
import { ERROR_FETCHING_CATEGORIES } from '../messages/errors';
import { getStoreId } from '../order/selectors';
import { GET_CATEGORIES, loadCategoriesFailure, loadCategoriesSuccess } from './actions';

export function* fetchCategories() {
  const storeId = yield select(getStoreId);

  try {
    const data = yield call(apis.categoriesList, storeId);

    yield put(loadCategoriesSuccess(data));
  } catch (error) {
    logError('category fetch failed', error);
    yield put(loadCategoriesFailure(ERROR_FETCHING_CATEGORIES));
  }
}

function* categoriesSaga() {
  yield takeLatest(GET_CATEGORIES, fetchCategories);
}

export default categoriesSaga;
