export const encodeParam = param => encodeURIComponent(param.toLowerCase());
