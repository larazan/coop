import isEmpty from 'lodash/fp/isEmpty';
import { all, call, put, select, takeEvery } from 'redux-saga/effects';
import { cleanSearchTerm } from '../../api/cms/banner/utilities';
import { apis } from '../../api/dgApi';
import { fromEntries } from '../../utils/collections';
import { isBasketCrossSellEnabled, isBasketDidYouForgetEnabled } from '../../utils/featureFlag';
import { getCrossSellGtins } from '../basket/selectors.shared';
import { error as logError } from '../logging/loggerSaga';
import { loadProductsByGtin } from '../products/actions';
import {
  productsListsAddItem,
  relatedProductsAddItems,
  relatedProductsPruneCache,
  RELATED_PRODUCTS_GET_CROSS_SELL,
  supplierBannerAddItem,
  supplierBannerAddToCache,
  supplierBannerRemoveItem,
  campaignSuccess,
  SUPPLIER_BANNER_BY_CATEGORY_ID,
  SUPPLIER_BANNER_BY_PAGE,
  SUPPLIER_BANNER_BY_SEARCH_TERM,
  FETCH_CAMPAIGN_REQUEST
} from './actions';
import { getBasketUnrelatedGtins, productsListRequiresRefresh, requiresRefresh } from './selectors';

function* refreshBanner(key) {
  // test if the key is cached / expired
  const refresh = yield select(requiresRefresh(key));
  if (!refresh) {
    return false;
  }

  // store in the cache
  yield put(supplierBannerAddToCache(key));
  return true;
}

export function* getBannerByKey({ getBy, key }) {
  try {
    const refresh = yield refreshBanner(key);
    if (!refresh) {
      return;
    }

    const banner = yield call(getBy, key);

    if (!banner) {
      // remove inactive banners from cache
      yield put(supplierBannerRemoveItem(key));
      return;
    }

    const { imageAltText, images, linkUrl, termsAndConditions } = banner;

    yield put(
      supplierBannerAddItem({
        key,
        imageAltText,
        images,
        linkUrl,
        termsAndConditions
      })
    );
  } catch (error) {
    yield logError('failed to get banner', error);
  }
}

function* supplierBannerByCategoryIdWorker({ payload }) {
  const { categoryId } = payload;

  yield call(getBannerByKey, { getBy: apis.cms.banners.getByCategoryId, key: { categoryId } });
}

function* supplierBannerBySearchTermWorker({ payload }) {
  const { searchTerm: raw } = payload;

  const searchTerm = cleanSearchTerm(raw);

  yield call(getBannerByKey, {
    getBy: apis.cms.banners.getBannerBySearchTerm,
    key: { searchTerm }
  });
}

function* supplierBannerByPageWorker({ payload }) {
  const { page } = payload;

  yield call(getBannerByKey, { getBy: apis.cms.banners.getByPage, key: { page } });
}

export function* relatedProductsWorker() {
  if (!isBasketCrossSellEnabled()) {
    return;
  }

  yield put(relatedProductsPruneCache());

  const gtins = yield select(getBasketUnrelatedGtins);
  if (!gtins.length) {
    return;
  }

  const response = yield all(
    gtins.map(gtin => {
      return call(apis.cms.relatedProducts.getRelatedProducts, gtin);
    })
  );

  const related = fromEntries(response);
  yield put(relatedProductsAddItems(related));
}

export function* productsListWorker({ payload }) {
  const { type } = payload;

  const refresh = yield select(productsListRequiresRefresh(type));
  if (!refresh) {
    return;
  }

  const list = yield call(apis.cms.productsLists.getListByType, type);

  if (list) {
    yield put(productsListsAddItem(list));
  }
}

function* getAllCrossSellWorker({ payload }) {
  try {
    // prettier-ignore
    yield all([
      call(relatedProductsWorker),
      call(productsListWorker, { payload })
    ]);

    const crossSellGtins = yield select(getCrossSellGtins);
    if (!isEmpty(crossSellGtins)) {
      yield put(loadProductsByGtin(crossSellGtins));
    }
  } catch (error) {
    yield logError('failed to load cross-sell', error);
  }
}

function* getCampaignWorker({ payload: { uri } }) {
  try {
    const response = yield call(apis.cms.getCampaign, { uri });

    yield put(campaignSuccess(response));
  } catch (error) {
    yield logError('failed to fetch campaign', error);
  }
}

function* cmsSaga() {
  yield takeEvery(SUPPLIER_BANNER_BY_CATEGORY_ID, supplierBannerByCategoryIdWorker);
  yield takeEvery(SUPPLIER_BANNER_BY_SEARCH_TERM, supplierBannerBySearchTermWorker);
  yield takeEvery(SUPPLIER_BANNER_BY_PAGE, supplierBannerByPageWorker);
  yield takeEvery(FETCH_CAMPAIGN_REQUEST, getCampaignWorker);

  if (isBasketDidYouForgetEnabled()) {
    yield takeEvery(RELATED_PRODUCTS_GET_CROSS_SELL, getAllCrossSellWorker);
  }
}

export default cmsSaga;
