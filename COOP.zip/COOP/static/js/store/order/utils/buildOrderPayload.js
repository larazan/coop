import { compact, omit } from 'lodash/fp';
import { v4 as uuidv4 } from 'uuid';
import { DELIVERY_CHARGE_EAN, PLASTIC_BAG_EAN } from '../../../constants';
import formatPhone from '../../../utils/formatPhone';

const bags = {
  sku: PLASTIC_BAG_EAN,
  quantity: 2,
  allow_replace: false,
  type: 2,
  unit_price: { price: 0.1, price_vat: 0.1 },
  row_price: { price: 0.2, price_vat: 0.2 }
};

const delivery = {
  sku: DELIVERY_CHARGE_EAN,
  quantity: 1,
  allow_replace: false,
  type: 5,
  unit_price: { price: 0, price_vat: 0 },
  row_price: { price: 0, price_vat: 0 }
};

export const customerDetails = ({ fullName, email, mobilePhone }) => ({
  name: fullName,
  email,
  phone: formatPhone(mobilePhone)
});

// FIXME trim or provide a default? Can you end up with a blank string of n-length here?
export const customerInfo = ({ membershipNumber }) =>
  membershipNumber === '' ? {} : { loyalty_card_id: membershipNumber };

// FIXME trim or provide a default? Can you end up with a blank string of n-length here?
export const driverNotes = ({ messageToDriver: message }) =>
  message === '' ? null : [{ type: 'driver', message }];

export const deliverySlot = ({ id, startsAt, endsAt, date }) => ({
  id: parseInt(id, 10),
  start_time: startsAt,
  end_time: endsAt,
  delivery_date: date
});

export const billingAddress = () => ({});

export const paymentMethod = () => ({
  backend: 'aci',
  type: 'online',
  configuration: {
    success_url: 'https:web-staging-coop.foodieservices.com/checkout/thank-you',
    failure_url: 'https:web-staging-coop.foodieservices.com/checkout/payment/failed',
    cancel_url: 'https:web-staging-coop.foodieservices.com/checkout-cancel',
    project_code: 'ACI'
  },
  services: [
    { type: 'card', name: 'VISA', code: 'VISA', fee: { price: 0, currency: 'GBP' } },
    { type: 'card', name: 'MASTERCARD', code: 'MASTERCARD', fee: { price: 0, currency: 'GBP' } }
  ]
});

export const orchestrationId = () => uuidv4();

export const placeId = ({ id }) => id;

export const deliveryAddress = ({ address, checkoutDetails }) => {
  const formatted_address = address.displayName;
  return {
    ...customerDetails(checkoutDetails),
    address: { ...omit('displayName', address), formatted_address }
  };
};

export const collectionAddress = ({ address: { displayName }, checkoutDetails }) => ({
  ...customerDetails(checkoutDetails),
  address: {
    name: displayName,
    formatted_address: displayName
  }
});

export const partsDeliveryMethod = ({ address, checkoutDetails, isCollection, slot }) => {
  const id = uuidv4();

  const rtn = {
    // FIXME where does this value come from?
    provider_id: '124bf99ad',
    type: 'foodie',
    service: {
      id,
      code: isCollection ? 'pickup' : 'home-delivery',
      price: { min: 0, currency: 'GBP' },
      delivery_slot: deliverySlot(slot),
      address: isCollection
        ? collectionAddress({ address, checkoutDetails })
        : deliveryAddress({ address, checkoutDetails })
    },
    id
  };

  const notes = driverNotes(checkoutDetails);
  if (notes) {
    rtn.notes = notes;
  }

  return rtn;
};

export const externalData = ({ evaluate, store }) => ({
  dg: {
    order: {
      place_ext_id: store.extId
    }
  },
  coop: {
    basket: evaluate
  }
});

// nb. this exists so we can mock each method in isolation -
//  is it correct to use mocks here, or should we test the whole?
export const lib = {
  billingAddress,
  customerDetails,
  customerInfo,
  externalData,
  orchestrationId,
  partsDeliveryMethod,
  paymentMethod,
  placeId
};

export const partsProducts = ({ checkoutDetails: { carrierBags }, isCollection, products }) => {
  // prettier-ignore
  return compact([
    ...products,
    carrierBags ? bags : null,
    isCollection ? null : delivery
  ]);
};

export const buildParts = ({ address, checkoutDetails, isCollection, products, slot, store }) => [
  {
    orchestration_id: lib.orchestrationId(),
    place_id: lib.placeId(store),
    delivery_method: lib.partsDeliveryMethod({ address, checkoutDetails, isCollection, slot }),
    products: partsProducts({ checkoutDetails, isCollection, products })
  }
];

// nb. and then we need to attach this here as no forward ref
lib.buildParts = buildParts;

export const build = ({
  address,
  checkoutDetails,
  evaluate,
  isCollection,
  products = [],
  slot,
  store
}) => ({
  customer_info: lib.customerInfo(checkoutDetails),
  external_data: lib.externalData({ evaluate, store }),
  customer_address: lib.customerDetails(checkoutDetails),
  billing_address: lib.billingAddress(),
  payment_method: lib.paymentMethod(),
  orchestration_id: lib.orchestrationId(),
  place_id: lib.placeId(store),
  editable: true,
  cancellable: true,
  parts: lib.buildParts({ address, checkoutDetails, isCollection, products, store, slot })
});
