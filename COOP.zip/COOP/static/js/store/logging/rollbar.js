import Rollbar from 'rollbar';
import { Logger } from './logger';

const convert = data => {
  if (data instanceof Error) {
    return { error: data.message };
  }
  return data;
};

export class RollbarLogger extends Logger {
  constructor(accessToken, environment) {
    super();

    this.rollbar = new Rollbar({
      accessToken,
      captureIp: 'anonymize',
      captureUncaught: true,
      captureUnhandledRejections: true,
      payload: {
        environment
      },
      scrubFields: ['email', 'fullName', 'membershipNumber', 'mobilePhone']
    });
  }

  critical(message, data = null) {
    this.rollbar.critical(message, convert(data));
  }

  error(message, data = null) {
    this.rollbar.error(message, convert(data));
  }

  warning(message, data = null) {
    this.rollbar.warning(message, convert(data));
  }

  info(message, data = null) {
    this.rollbar.info(message, convert(data));
  }

  debug(message, data = null) {
    this.rollbar.debug(message, convert(data));
  }
}

export const build = ({ accessToken, environment } = {}) =>
  new RollbarLogger(accessToken, environment);
