import { get, isEmpty, keys, map, values } from 'lodash/fp';
import { createSelector } from 'reselect';
import { MIN_BASKET_VALUE } from '../../constants';
import formatPrice from '../../utils/formatPrice';
import { isFetchingFor } from '../shared';

export const isFetching = state => isFetchingFor('basket', state);

export const itemsInBasket = state => state.basket.items;

export const distinctItemsInBasketCount = state => keys(itemsInBasket(state)).length;

export const totalItemsInBasketCount = state => {
  const items = values(itemsInBasket(state));

  return items.reduce((acc, curr) => {
    const quantity = get('quantity', curr) || 0;

    return acc + quantity;
  }, 0);
};

export const basketUnavailable = state => ({
  products: values(state.basket.unavailable),
  unavailableIn: state.basket.unavailableIn
});

export const orderTotals = ({ order }) => {
  return order
    ? {
        items: order.subtotal,
        savings: order.discount,
        staffDiscount: order.staffDiscount,
        subtotal: order.subtotal - order.discount,
        total: order.total,
        voucherDiscount: order.voucherDiscount
      }
    : {};
};

export const getBasketItemGtins = state => {
  const items = itemsInBasket(state);
  return map(get('gtin'), items);
};

export const getGtinsForItems = items => map(get('gtin'), items);

const formattedTotal = totalSelector => createSelector(totalSelector, formatPrice);

export const basketTotal = () =>
  createSelector(orderTotals, totals => totals.items - totals.savings);

export const formattedBasketTotal = state => formattedTotal(basketTotal(state));

const orderTotal = () => createSelector(orderTotals, totals => totals.total);

export const formattedOrderTotal = state => formattedTotal(orderTotal(state));

export const isBasketEmpty = state => isEmpty(state.basket.items);

export const isNotMinBasketValue = state => basketTotal()(state) < MIN_BASKET_VALUE;
export const meetsMinimumBasketValue = state => {
  return basketTotal()(state) >= MIN_BASKET_VALUE;
};
