export const RESET_APP_STATE = 'complete/RESET_APP_STATE';

export const resetAppState = payload => ({
  type: RESET_APP_STATE,
  payload
});
