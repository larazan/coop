import { ERROR_POSTCODE_NOT_IN_SERVICE_AREA, TRY_NEW_POSTCODE } from '../addresses/actions';
import { STORE_SELECTED } from '../order/actions';
import { SELECT_POSTCODE, SELECT_POSTCODE_ERROR, SELECT_POSTCODE_SUCCESS } from './actions';

export const initialState = {
  isFetching: false,
  error: null,
  postcode: null,
  coordinates: null,
  deliveryStores: null,
  collectionStores: null
};

const selectPostcode = () => ({
  ...initialState,
  isFetching: true
});

const selectPostcodeSuccess = (
  state,
  { postcode, coordinates, collectionStores, deliveryStores }
) => ({
  ...state,
  isFetching: false,
  postcode,
  coordinates,
  collectionStores,
  deliveryStores
});

const selectPostcodeError = (state, { error }) => ({
  ...state,
  error,
  isFetching: false
});

const resetShoppingInOnStoreSelection = () => initialState;

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case SELECT_POSTCODE:
      return selectPostcode();
    case SELECT_POSTCODE_SUCCESS:
      return selectPostcodeSuccess(state, action.payload);
    case SELECT_POSTCODE_ERROR:
      return selectPostcodeError(state, action.payload);
    case ERROR_POSTCODE_NOT_IN_SERVICE_AREA:
      return { ...state, isFetching: false };
    case TRY_NEW_POSTCODE:
      return initialState;
    case STORE_SELECTED:
      return resetShoppingInOnStoreSelection();
    default:
      return state;
  }
};

export default reducer;
