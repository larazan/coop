export const CONFIRM_SLOT = 'slots/CONFIRM_SLOT';

export const CLEAR_EXPIRED_SLOT = 'slots/CLEAR_EXPIRED_SLOT';

export const REFRESH_SLOTS = 'slots/REFRESH_SLOTS';
export const REFRESH_SLOTS_SUCCESS = 'slots/REFRESH_SLOTS_SUCCESS';
export const REFRESH_SLOTS_FAILURE = 'slots/REFRESH_SLOTS_FAILURE';

export const confirmSlot = (id, date) => ({
  type: CONFIRM_SLOT,
  payload: { id, date }
});

export const clearExpiredSlot = () => ({
  type: CLEAR_EXPIRED_SLOT
});

export const refreshSlots = payload => ({
  type: REFRESH_SLOTS,
  payload
});

export const refreshSlotsSuccess = payload => ({
  type: REFRESH_SLOTS_SUCCESS,
  payload
});

export const refreshSlotsFailure = () => ({
  type: REFRESH_SLOTS_FAILURE
});
