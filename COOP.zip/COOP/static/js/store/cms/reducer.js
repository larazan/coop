import { differenceInMinutes } from 'date-fns';
import { isEqual, mapValues, pickBy, reject } from 'lodash/fp';
import { now } from '../../utils/datetime';
import {
  PRODUCTS_LISTS_ADD_ITEM,
  RELATED_PRODUCTS_ADD_ITEMS,
  RELATED_PRODUCTS_PRUNE_CACHE,
  SUPPLIER_BANNER_ADD_ITEM,
  SUPPLIER_BANNER_ADD_TO_CACHE,
  SUPPLIER_BANNER_REMOVE_ITEM,
  FETCH_CAMPAIGN_REQUEST,
  FETCH_CAMPAIGN_SUCCESS
} from './actions';
import { cacheExpiryInMinutes } from './constants';

export const initialState = {
  banners: {
    items: [],
    cache: []
  },
  relatedProducts: {},
  productsLists: []
};

const supplierBannerAddItem = (
  state,
  { key, imageAltText, images, linkUrl, termsAndConditions }
) => {
  const others = reject(each => isEqual(each.key, key), state.banners.items);
  const item = { key, value: { imageAltText, images, linkUrl, termsAndConditions } };

  return {
    ...state,
    banners: {
      ...state.banners,
      items: [...others, item]
    }
  };
};

const supplierBannerRemoveItem = (state, { key }) => {
  const items = reject(each => isEqual(each.key, key), state.banners.items);

  return {
    ...state,
    banners: {
      ...state.banners,
      items
    }
  };
};

const supplierBannerAddToCache = (state, { cacheKey }) => {
  const others = reject(each => isEqual(each.key, cacheKey), state.banners.cache);
  const cacheItem = { key: cacheKey, lastModified: new Date() };

  return {
    ...state,
    banners: {
      ...state.banners,
      cache: [...others, cacheItem]
    }
  };
};

const relatedProductsAddItems = (state, items) => {
  const timedItems = mapValues(item => ({ related: item, lastModified: now() }), items);

  return {
    ...state,
    relatedProducts: { ...state.relatedProducts, ...timedItems }
  };
};

const relatedProductsPruneCache = state => {
  const refreshedRelatedProducts = pickBy(
    cached => differenceInMinutes(now(), cached.lastModified) <= cacheExpiryInMinutes,
    state.relatedProducts
  );

  return {
    ...state,
    relatedProducts: refreshedRelatedProducts
  };
};

const productsListsAddItem = (state, item) => {
  const { name } = item;
  const others = reject(each => isEqual(each.name, name), state.productsLists);

  return {
    ...state,
    productsLists: [...others, { ...item, lastModified: now() }]
  };
};

const campaignFetching = state => {
  return {
    ...state,
    campaign: { isFetching: true }
  };
};

const campaign = (state, item) => {
  return {
    ...state,
    campaign: { ...item, isFetching: false }
  };
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case SUPPLIER_BANNER_ADD_ITEM:
      return supplierBannerAddItem(state, action.payload);
    case SUPPLIER_BANNER_REMOVE_ITEM:
      return supplierBannerRemoveItem(state, action.payload);
    case SUPPLIER_BANNER_ADD_TO_CACHE:
      return supplierBannerAddToCache(state, action.payload);
    case RELATED_PRODUCTS_ADD_ITEMS:
      return relatedProductsAddItems(state, action.payload);
    case RELATED_PRODUCTS_PRUNE_CACHE:
      return relatedProductsPruneCache(state);
    case PRODUCTS_LISTS_ADD_ITEM:
      return productsListsAddItem(state, action.payload);
    case FETCH_CAMPAIGN_REQUEST:
      return campaignFetching(state);
    case FETCH_CAMPAIGN_SUCCESS:
      return campaign(state, action.payload);
    default:
      return state;
  }
};

export default reducer;
