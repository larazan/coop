import { RESET_APP_STATE } from '../complete/actions';
import { FETCH_INITIAL_PRODUCTS } from '../products/actions';
import { GET_CATEGORIES, GET_CATEGORIES_FAILURE, GET_CATEGORIES_SUCCESS } from './actions';

export const initialState = {
  items: {},
  isFetching: false,
  hasInitialLoad: false,
  selected: null
};

const categoryReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_CATEGORIES:
      return { ...state, isFetching: true };
    case GET_CATEGORIES_SUCCESS:
      return {
        ...state,
        items: action.payload.items,
        isFetching: false,
        hasInitialLoad: true
      };
    case GET_CATEGORIES_FAILURE: {
      return { ...state, isFetching: false, selected: null };
    }
    case FETCH_INITIAL_PRODUCTS: {
      const id = action.payload.parentCategoryId;
      return { ...state, selected: id || state.selected };
    }
    case RESET_APP_STATE:
      return initialState;
    default:
      return state;
  }
};

export default categoryReducer;
