import { find, flatMap, flow } from 'lodash/fp';

function getSlotById(slotId, slotMap) {
  return flow(
    flatMap(x => x),
    find(['id', slotId])
  )(slotMap);
}

export default getSlotById;
