import { addMessage } from '../messages/actions';

export const GET_CATEGORIES = 'categories/FETCH';
export const GET_CATEGORIES_SUCCESS = 'categories/FETCH_SUCCESS';
export const GET_CATEGORIES_FAILURE = 'categories/FETCH_FAILURE';

export const loadCategories = () => ({
  type: GET_CATEGORIES
});

export const loadCategoriesSuccess = items => ({
  type: GET_CATEGORIES_SUCCESS,
  payload: { items }
});

export const loadCategoriesFailure = error => addMessage(GET_CATEGORIES_FAILURE, error);
