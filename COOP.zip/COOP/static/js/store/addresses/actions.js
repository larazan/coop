import { addMessage } from '../messages/actions';

export const SEARCH_FOR_ADDRESS = 'address/SEARCH_FOR_ADDRESS';
export const SEARCH_FOR_ADDRESS_SUCCESS = 'address/SEARCH_FOR_ADDRESS_SUCCESS';
export const SEARCH_FOR_ADDRESS_FAILURE = 'address/SEARCH_FOR_ADDRESS_FAILURE';
export const SEARCH_FOR_ADDRESS_ERROR = 'address/SEARCH_FOR_ADDRESS_ERROR';

export const GET_ADDRESS_LIST = 'address/GET_ADDRESS_LIST';

export const GET_DELIVERY_ADDRESSES_SUCCESS = 'address/GET_DELIVERY_ADDRESSES_SUCCESS';
export const GET_DELIVERY_ADDRESSES_OPTIONS_SUCCESS =
  'address/GET_DELIVERY_ADDRESSES_OPTIONS_SUCCESS';

export const ERROR_POSTCODE_NOT_IN_SERVICE_AREA = 'address/POSTCODE_NOT_IN_SERVICE_AREA';
export const TRY_NEW_POSTCODE = 'address/TRY_NEW_POSTCODE';

export const GET_COLLECTION_STORES = 'address/GET_COLLECTION_STORES';
export const GET_COLLECTION_STORES_SUCCESS = 'address/GET_COLLECTION_STORES_SUCCESS';
export const GET_COLLECTION_STORES_ERROR = 'address/GET_COLLECTION_STORES_ERROR';

export const CLEAR_COLLECTION_STORES = 'address/CLEAR_COLLECTION_STORES';

export const searchForAddress = postcode => ({
  type: SEARCH_FOR_ADDRESS,
  payload: { postcode }
});

export const searchForAddressSuccess = options => ({
  type: SEARCH_FOR_ADDRESS_SUCCESS,
  payload: options
});

export const searchForAddressError = error => ({
  type: SEARCH_FOR_ADDRESS_ERROR,
  payload: error
});

export const searchForAddressFailure = error => addMessage(SEARCH_FOR_ADDRESS_FAILURE, error);

export const getAddressListFromPostcode = postcode => ({
  type: GET_ADDRESS_LIST,
  payload: { postcode }
});

export const postcodeNotInServiceArea = () => ({
  type: ERROR_POSTCODE_NOT_IN_SERVICE_AREA
});

export const tryNewPostcodeFromNotInServiceAreaError = () => ({
  type: TRY_NEW_POSTCODE
});

export const getDeliveryAddressesSuccess = ({
  coordinates,
  deliveryStores,
  options,
  postcode
}) => ({
  type: GET_DELIVERY_ADDRESSES_SUCCESS,
  payload: {
    coordinates,
    deliveryStores,
    options,
    postcode
  }
});

export const getDeliveryAddressesOptionsSuccess = options => ({
  type: GET_DELIVERY_ADDRESSES_OPTIONS_SUCCESS,
  payload: {
    options
  }
});

export const getCollectionStores = postcode => ({
  type: GET_COLLECTION_STORES,
  payload: { postcode }
});

// ! coordinates ➡️ address
// ! postcode ➡️ address
export const getCollectionStoresSuccess = ({ collectionStores, coordinates, postcode }) => ({
  type: GET_COLLECTION_STORES_SUCCESS,
  payload: { collectionStores, coordinates, postcode }
});

export const getCollectionStoresError = error => ({
  type: GET_COLLECTION_STORES_ERROR,
  payload: { error }
});

export const clearCollectionStores = () => ({
  type: CLEAR_COLLECTION_STORES
});
