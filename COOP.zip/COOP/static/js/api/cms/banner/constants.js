export const bannerImages = Object.freeze({
  small: 'bannerImageSmall',
  medium: 'bannerImageMedium',
  large: 'bannerImageLarge'
});

export const pageTypes = Object.freeze({
  homepage: 'homepage'
});
