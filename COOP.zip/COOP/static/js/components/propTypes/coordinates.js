import PropTypes from 'prop-types';

export default {
  latitude: PropTypes.number.isRequired,
  longitude: PropTypes.number.isRequired
};
