export const cacheExpiryInMinutes = 10;

export const maxCrossSellItems = 6;
