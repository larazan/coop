import { flow, getOr } from 'lodash/fp';
import { isFetchingFor } from '../shared';

export const isFetching = state => isFetchingFor('addresses', state);

const getAddresses = state => state.addresses;

export const notInServiceArea = state => getAddresses(state).notInServiceArea;

export const getError = state => getAddresses(state).error;

export const getPostcode = state => getAddresses(state).postcode;

export const getPostcodeCoordinates = state => getAddresses(state).postcodeCoordinates;

export const getOptions = state => getAddresses(state).items;

export const getDeliveryStoreId = state =>
  flow(getAddresses, getOr(null, 'deliveryStores.0.id'))(state);
