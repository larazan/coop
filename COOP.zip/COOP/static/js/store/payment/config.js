export const getRetryConfig = () => {
  return { maxRetries: 5, initialDelay: 1000 };
};
