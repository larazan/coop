import { getOr } from 'lodash/fp';
import { getApi } from './shared';

const getBasket = state => getApi(state).basket;

export const getBasketEvaluate = state => getOr({}, 'evaluate', getBasket(state));
export const getBasketPromotions = state => getOr({}, 'promotions', getBasketEvaluate(state));

export const getBasketEvaluateValue = state => getBasketEvaluate(state).cart_value;
