import { get } from 'lodash/fp';
import { getStoreId } from '../order/selectors';

export const getStores = state => state.stores;

export const getStoreById = (state, id) => {
  const store = getStores(state)[id];

  return store;
};

export const getCurrentStore = state => {
  const currentStoreId = getStoreId(state);
  const currentStore = getStoreById(state, currentStoreId);
  return currentStore;
};

export const getCurrentStoreExtId = state => {
  const currentExtId = get('extId', getCurrentStore(state));
  return currentExtId;
};
