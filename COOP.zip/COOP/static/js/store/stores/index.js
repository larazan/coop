import * as storesActions from './actions';
import storesSaga from './operations';
import reducer, { initialState } from './reducer';
import * as storesSelectors from './selectors';

export { initialState, storesActions, storesSaga, storesSelectors };

export default reducer;
