export default number => number.replace(/^\s*(00|\+)44/, '0').replace(/\s/g, '');
