import { FULFILMENT_TYPE_COLLECTION, FULFILMENT_TYPE_DELIVERY } from '../../constants';
import { addMessage } from '../messages/actions';

export const SELECT_ADDRESS = 'order/SELECT_ADDRESS';
export const SELECT_ADDRESS_SUCCESS = 'order/SELECT_ADDRESS_SUCCESS';

export const PLACE_ORDER_REQUEST = 'order/PLACE_ORDER_REQUEST';
export const PLACE_ORDER_FAILURE = 'order/PLACE_ORDER_FAILURE';
export const PLACE_ORDER_FAILURE_SLOT = 'order/PLACE_ORDER_FAILURE_SLOT';
export const PLACE_ORDER_SUCCESS = 'order/PLACE_ORDER_SUCCESS';

export const SWITCH_FULFILMENT_TYPE = 'order/SWITCH_FULFILMENT_TYPE';

export const SELECT_COLLECTION_STORE = 'order/SELECT_COLLECTION_STORE';
export const SELECT_DELIVERY_STORE = 'order/SELECT_DELIVERY_STORE';

export const STORE_SELECTED = 'order/STORE_SELECTED';

const switchFulfilmentType = type => ({ type: SWITCH_FULFILMENT_TYPE, payload: type });
export const switchToCollection = () => switchFulfilmentType(FULFILMENT_TYPE_COLLECTION);
export const switchToDelivery = () => switchFulfilmentType(FULFILMENT_TYPE_DELIVERY);

export const selectAddress = ({ link, slot, storeId }) => ({
  type: SELECT_ADDRESS,
  payload: {
    link,
    slot,
    storeId
  }
});

export const selectAddressSuccess = address => ({
  type: SELECT_ADDRESS_SUCCESS,
  payload: {
    ...address
  }
});

// on Payment page load
export const placeOrder = (slot, products) => ({
  type: PLACE_ORDER_REQUEST,
  payload: { slot, products }
});

// before rendering Payment screen; set flag in redux
export const placeOrderSuccess = orderDetails => ({
  type: PLACE_ORDER_SUCCESS,
  payload: orderDetails
});

export const placeOrderFailure = error => addMessage(PLACE_ORDER_FAILURE, error);

export const placeOrderFailureSlot = () => ({ type: PLACE_ORDER_FAILURE_SLOT });

export const selectCollectionStore = ({ id, name }) => ({
  type: SELECT_COLLECTION_STORE,
  payload: { id, name }
});

export const selectDeliveryStore = ({ id }) => ({
  type: SELECT_DELIVERY_STORE,
  payload: { id }
});

export const notifyHasSelectedStore = () => ({
  type: STORE_SELECTED
});
