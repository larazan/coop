import { SELECT_ADDRESS, SELECT_ADDRESS_SUCCESS } from '../order/actions';
import { SELECT_POSTCODE_SUCCESS } from '../shoppingIn/actions';
import {
  CLEAR_COLLECTION_STORES,
  ERROR_POSTCODE_NOT_IN_SERVICE_AREA,
  GET_COLLECTION_STORES,
  GET_COLLECTION_STORES_ERROR,
  GET_COLLECTION_STORES_SUCCESS,
  GET_DELIVERY_ADDRESSES_OPTIONS_SUCCESS,
  GET_DELIVERY_ADDRESSES_SUCCESS,
  SEARCH_FOR_ADDRESS,
  SEARCH_FOR_ADDRESS_ERROR,
  SEARCH_FOR_ADDRESS_FAILURE,
  SEARCH_FOR_ADDRESS_SUCCESS,
  TRY_NEW_POSTCODE
} from './actions';

export const initialState = {
  isFetching: false,
  error: null,
  notInServiceArea: false,

  // TODO should we group collection and delivery under their own key?
  //  as it's slightly confusing that we're mixing the usage of this state
  collectionStores: null,

  items: null, // delivery addresses
  deliveryStores: null,

  // !FIXME: make this just "coordinates"
  postcodeCoordinates: null,
  postcode: null
};

const searchForAddress = state => ({
  ...initialState,
  collectionStores: state.collectionStores,
  deliveryStores: state.deliveryStores,
  postcodeCoordinates: state.postcodeCoordinates,
  postcode: state.postcode,
  isFetching: true
});

const searchForAddressSuccess = (state, options) => ({
  ...state,
  isFetching: false,
  items: options
});

const selectAddress = state => {
  return { ...state, isFetching: true };
};

// we need the state until the fully resolved address with parts
// is returned
const selectAddressSuccess = state => ({
  ...state,
  items: null,
  isFetching: false
});

const storeErrorFromPostcodeSearch = (state, error) => ({
  ...state,
  error: { ...error },
  isFetching: false
});

const getCollectionStoresSuccess = (state, { collectionStores, coordinates, postcode }) => ({
  ...state,
  isFetching: false,
  collectionStores,
  postcode,
  postcodeCoordinates: coordinates
});

const getCollectionStoresError = (state, { error }) => ({
  ...state,
  error,
  isFetching: false
});

const replicateShoppingInDetails = (state, { postcode, coordinates, collectionStores }) => ({
  ...state,
  postcode,
  postcodeCoordinates: coordinates,
  // replicate stores
  collectionStores,
  // clear delivery details as this will need a new search
  deliveryStores: null,
  items: null
});

const clearCollectionStores = state => ({
  ...state,
  collectionStores: null
});

const getDeliveryAddressSuccess = (state, { coordinates, deliveryStores, options, postcode }) => ({
  ...state,
  isFetching: false,
  postcodeCoordinates: coordinates,
  deliveryStores,
  items: options,
  postcode
});

const getDeliveryAddressOptionsSuccess = (state, { options }) => ({
  ...state,
  isFetching: false,
  items: options
});

const addressReducer = (state = initialState, action) => {
  switch (action.type) {
    case SEARCH_FOR_ADDRESS:
      return searchForAddress(state);
    case SEARCH_FOR_ADDRESS_SUCCESS:
      return searchForAddressSuccess(state, action.payload);
    case SEARCH_FOR_ADDRESS_ERROR:
      return storeErrorFromPostcodeSearch(state, action.payload);
    case SEARCH_FOR_ADDRESS_FAILURE:
      return { ...initialState, isFetching: false };
    case SELECT_ADDRESS:
      return selectAddress(state);
    case SELECT_ADDRESS_SUCCESS:
      return selectAddressSuccess(state);
    case ERROR_POSTCODE_NOT_IN_SERVICE_AREA:
      return { ...state, notInServiceArea: true, isFetching: false };
    case TRY_NEW_POSTCODE:
      return initialState;
    case GET_COLLECTION_STORES:
      return { ...state, error: null, isFetching: true };
    case GET_COLLECTION_STORES_SUCCESS:
      return getCollectionStoresSuccess(state, action.payload);
    case GET_COLLECTION_STORES_ERROR:
      return getCollectionStoresError(state, action.payload);
    case SELECT_POSTCODE_SUCCESS:
      return replicateShoppingInDetails(state, action.payload);
    case CLEAR_COLLECTION_STORES:
      return clearCollectionStores(state);
    case GET_DELIVERY_ADDRESSES_SUCCESS:
      return getDeliveryAddressSuccess(state, action.payload);
    case GET_DELIVERY_ADDRESSES_OPTIONS_SUCCESS:
      return getDeliveryAddressOptionsSuccess(state, action.payload);
    default:
      return state;
  }
};

export default addressReducer;
