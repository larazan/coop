export function checkoutFunnel({ payload }) {
  const { products, step, revenue } = payload;
  return {
    event: 'checkout',
    eventCategory: 'Ecommerce',
    eventAction: 'Checkout',
    eventLabel: step,
    eventValue: revenue,
    ecommerce: {
      currencyCode: 'GBP',
      checkout: {
        actionField: {
          step
        }
      },
      products
    }
  };
}

export function purchase({ payload }) {
  const {
    deliveryCharges,
    eventLabel,
    id,
    offers,
    orderDiscount,
    paymentType,
    products,
    promoCode,
    revenue,
    store,
    transactionType
  } = payload;

  return {
    event: 'purchase',
    eventCategory: 'Ecommerce',
    eventAction: 'Purchase',
    eventLabel,
    eventValue: revenue,
    ecommerce: {
      currencyCode: 'GBP',
      purchase: {
        actionField: {
          deliveryCharges,
          id,
          offers,
          orderDiscount,
          paymentType,
          promoCode,
          revenue,
          store,
          transactionType
        }
      },
      products
    }
  };
}
