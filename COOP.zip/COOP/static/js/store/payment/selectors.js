import { isEmpty, isNull } from 'lodash/fp';
import { getOrder as getApiOrder } from '../api/selectors/order';
import { getCategories } from '../categories/selectors';
import { getMessages } from '../messages/selectors';
import { getOrder } from '../order/selectors';
import { getStateForPersistence } from '../selectors';
import { CLEAR_EXPIRED_SLOT } from '../slots/actions';

export const orderFailedDueToSlotExpiry = state => {
  const { isOrderPlaced } = getApiOrder(state);
  const { slot: orderSlot } = getOrder(state);
  const expiryMessage = getMessages(state)[CLEAR_EXPIRED_SLOT];
  const failedDueToSlot = !isOrderPlaced && !isEmpty(expiryMessage) && isNull(orderSlot);

  return failedDueToSlot;
};

export const persistBeforeRedirect = state => {
  const categories = getCategories(state);
  const alwaysPersisted = getStateForPersistence(state);

  // We need category names for analytics
  return { categories, ...alwaysPersisted };
};
