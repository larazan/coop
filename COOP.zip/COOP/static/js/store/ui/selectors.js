import { notInServiceArea } from '../addresses/selectors';

const getUi = state => state.ui;

export const getCookieBannerDismissed = state => getUi(state).cookieBannerDismissed;

export const getShowCheckAvailability = state =>
  getUi(state).setLocation && !notInServiceArea(state);
