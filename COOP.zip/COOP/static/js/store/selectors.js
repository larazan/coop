import { omit } from 'lodash/fp';
import { initialState } from './products/reducer';
import { getCookieBannerDismissed } from './ui/selectors';

export const isFetching = state => state.isFetching === true;

export const getStateForPersistence = state => {
  const {
    account,
    addresses,
    api,
    basket,
    checkout,
    order,
    products: { unavailable },
    shoppingIn,
    slots,
    stores
  } = state;

  return {
    account,
    addresses: omit(['error', 'notInServiceArea'], addresses),
    api,
    basket,
    checkout,
    order,
    products: { ...initialState, unavailable },
    shoppingIn,
    slots,
    stores,
    ui: { cookieBannerDismissed: getCookieBannerDismissed(state) }
  };
};
