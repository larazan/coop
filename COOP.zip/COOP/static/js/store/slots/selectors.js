import {
  concat,
  find,
  flatMap,
  flow,
  getOr,
  head,
  isEmpty,
  isNil,
  negate,
  sortBy
} from 'lodash/fp';
import { FULFILMENT_TYPE_DELIVERY } from '../../constants';
import { isFetching as fetching } from '../selectors';

const getSlots = state => state.slots;

export const isFetching = state => fetching(getSlots(state));

const getNextFrom = slots => {
  return flow(
    flatMap(x => x),
    sortBy(['date', 'startsAt']),
    head
  )(slots);
};

export const getCollection = state => getSlots(state).collection;

export const getDelivery = state => getSlots(state).delivery;

export const getNextCollection = state => getNextFrom(getCollection(state));

export const getNextDelivery = state => getNextFrom(getDelivery(state));

// nb. these work off state.slots not state as they're used in a memoized selector
export const getMemoizedById = (slotId, slots) => {
  const collection = flatMap(x => x, slots.collection);
  const delivery = flatMap(x => x, slots.delivery);

  return flow(concat, find(['id', slotId]))(collection, delivery);
};

export const isDelivery = ({ id, date }) => state => {
  return flow(getDelivery, getOr([], date), find(['id', id]), negate(isNil))(state);
};

export const isOtherTypeAvailable = type => state => {
  const collection = getCollection(state);
  const delivery = getDelivery(state);

  return type === FULFILMENT_TYPE_DELIVERY ? !isEmpty(collection) : !isEmpty(delivery);
};
