import { call, debounce, put, select } from 'redux-saga/effects';
import { apis } from '../../api/dgApi';
import { getStoreId } from '../order/selectors';
import { searchFailure, searchStartRequest, searchSuccess, SEARCH_REQUEST } from './actions';

const minimumSearchLength = 2;

function* performSearch({ payload }) {
  const { term } = payload;

  if (term.length > minimumSearchLength) {
    yield put(searchStartRequest());

    try {
      const storeId = yield select(getStoreId);

      const data = yield call(apis.searchList, {
        q: term,
        storeId
      });

      yield put(searchSuccess(data));
    } catch (error) {
      yield put(searchFailure(['']));
    }
  }
}

function* searchSaga() {
  yield debounce(500, SEARCH_REQUEST, performSearch);
}

export default searchSaga;
