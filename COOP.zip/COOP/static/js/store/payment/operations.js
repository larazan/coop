import { call, put, select, takeLatest } from 'redux-saga/effects';
import { apis } from '../../api/dgApi';
import { getOrderNumber } from '../api/selectors/order';
import { error as logError, info as logInfo } from '../logging/loggerSaga';
import { rejectOrderForSlot } from '../order/operations';
import { getCurrentStore } from '../stores/selectors';
import {
  finalizeOrderFailure,
  finalizeOrderSuccess,
  FINALIZE_ORDER,
  PAYMENT_SLOT_EXPIRED
} from './actions';
import { backOff } from './backOff';

export function* finalizeOrderWorker() {
  const orderNumber = yield select(getOrderNumber);
  const store = yield select(getCurrentStore);
  function* logRetry(error) {
    yield logInfo('retrying payment finalization', {
      error: error.body,
      orderNumber,
      store,
      status: error.status
    });
  }

  try {
    const res = yield call(backOff, apis.payment.finalizeOrder, { orderNumber }, logRetry);

    if (res.ok) {
      yield put(finalizeOrderSuccess());
    } else {
      yield logError('finalize order failure', {
        error: res.error.message,
        orderNumber,
        store,
        status: res.status
      });
      yield put(finalizeOrderFailure());
    }
  } catch (error) {
    yield logError('finalize order failure', { error: error.message, orderNumber, store });
    yield put(finalizeOrderFailure());
  }
}

function* slotExpiredPrePaymentWorker() {
  yield rejectOrderForSlot();
}

function* paymentSaga() {
  yield takeLatest(FINALIZE_ORDER, finalizeOrderWorker);
  yield takeLatest(PAYMENT_SLOT_EXPIRED, slotExpiredPrePaymentWorker);
}

export default paymentSaga;
