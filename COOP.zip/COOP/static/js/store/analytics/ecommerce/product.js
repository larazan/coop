export function detailView({ payload: { product } }) {
  const { brand, category, id, name, price, quantity } = product;
  return {
    ecommerce: {
      detail: {
        products: [
          {
            brand,
            category,
            id,
            name,
            price,
            quantity
          }
        ]
      }
    },
    event: 'detailView',
    eventAction: 'Detail View',
    eventCategory: 'Ecommerce',
    eventLabel: id,
    eventValue: null
  };
}
