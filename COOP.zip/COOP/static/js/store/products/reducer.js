import { getOr, includes, keyBy, partition } from 'lodash/fp';
import { FETCH_BASKET_PRODUCTS_SUCCESS } from '../basket/actions';
import { PRODUCTS_IN_STORE_RANGE, STORE_ID_CHANGED } from '../shoppingIn/actions';
import {
  FETCH_INITIAL_PRODUCTS,
  FETCH_MORE_PRODUCTS,
  FETCH_MORE_PRODUCTS_SUCCESS,
  FETCH_MORE_SEARCH_PRODUCTS,
  FETCH_MORE_SEARCH_PRODUCTS_SUCCESS,
  FETCH_PRODUCT,
  FETCH_PRODUCTS_BY_GTIN,
  FETCH_PRODUCTS_CANCEL,
  FETCH_PRODUCTS_SUCCESS,
  FETCH_PRODUCT_SUCCESS,
  FETCH_SEARCH_PRODUCTS,
  FETCH_SEARCH_PRODUCTS_SUCCESS
} from './actions';

const FETCHING_LIST = 'isFetchingList';
const FETCHING_MORE = 'isFetchingMore';
const FETCHING_DETAILS = 'isFetchingDetails';

export const initialState = {
  items: {},
  [FETCHING_LIST]: false,
  [FETCHING_DETAILS]: false,
  [FETCHING_MORE]: false,
  nextProductPage: {},
  totalProductCountByCategory: {},
  unavailable: {}
};

const getTotalCount = (parentCategoryId, state, pagination) => {
  if (!parentCategoryId) {
    return state.totalProductCountByCategory;
  }
  return { ...state.totalProductCountByCategory, [parentCategoryId]: pagination.totalCount };
};

const storeSingleProductDetails = (state, product) => {
  const isAvailable = !state.unavailable[product.id];
  return {
    ...state,
    items: isAvailable ? { ...state.items, [product.id]: product } : state.items,
    [FETCHING_DETAILS]: false
  };
};

const getNextPage = (nextSetMap, pagination, keyForNextPageMap) => {
  const nextPage = getOr(1, 'nextPage', pagination);

  if (keyForNextPageMap) {
    return { ...nextSetMap, [keyForNextPageMap]: nextPage };
  }

  return nextSetMap;
};

const storeProductsSuccess = (state, payload, isFetchingFlagName) => {
  const { items, pagination, parentCategoryId, searchTerm } = payload;
  const keyForPagination = parentCategoryId || searchTerm;

  return {
    ...state,
    items: { ...state.items, ...keyBy('id', items) },
    [isFetchingFlagName]: false,
    totalProductCountByCategory: getTotalCount(keyForPagination, state, pagination),
    nextProductPage: getNextPage(state.nextProductPage, pagination, keyForPagination)
  };
};

// FIXME: find a better way of handling the interaction between these two flags
const setFetchingList = state => ({
  ...state,
  [FETCHING_LIST]: true,
  [FETCHING_DETAILS]: true
});

const setFetchingDetails = state => ({ ...state, [FETCHING_DETAILS]: true });
const setFetchingMore = state => ({ ...state, [FETCHING_MORE]: true });

const partitionProductsBasedOnStoreRange = (state, { products: availableProductMasterIds }) => {
  const [available, unavailable] = partition(
    p => includes(p.masterProductId, availableProductMasterIds),
    state.items
  );

  return {
    ...state,
    items: keyBy('id', available),
    unavailable: keyBy('id', unavailable)
  };
};

const productReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_INITIAL_PRODUCTS:
    case FETCH_PRODUCTS_BY_GTIN:
    case FETCH_SEARCH_PRODUCTS:
      return setFetchingList(state);

    case FETCH_PRODUCTS_SUCCESS:
    case FETCH_BASKET_PRODUCTS_SUCCESS:
    case FETCH_SEARCH_PRODUCTS_SUCCESS: {
      return storeProductsSuccess(state, action.payload, FETCHING_LIST);
    }
    case FETCH_MORE_PRODUCTS_SUCCESS:
    case FETCH_MORE_SEARCH_PRODUCTS_SUCCESS: {
      return storeProductsSuccess(state, action.payload, FETCHING_MORE);
    }

    case FETCH_MORE_PRODUCTS:
    case FETCH_MORE_SEARCH_PRODUCTS:
      return setFetchingMore(state);

    case FETCH_PRODUCT:
      return setFetchingDetails(state);

    case FETCH_PRODUCT_SUCCESS:
      return storeSingleProductDetails(state, action.payload);

    case FETCH_PRODUCTS_CANCEL:
      return { ...state, isFetchingList: false };

    case PRODUCTS_IN_STORE_RANGE:
      return partitionProductsBasedOnStoreRange(state, action.payload);

    case STORE_ID_CHANGED:
      return { ...state, totalProductCountByCategory: {} };

    default:
      return state;
  }
};

export default productReducer;
