export const STORE_CHECKOUT_DETAILS = 'checkout/STORE_CHECKOUT_DETAILS';
export const STORE_CARRIER_BAGS = 'checkout/STORE_CARRIER_BAGS';

export const SET_USER_DETAILS = 'checkout/SET_USER_DETAILS';
export const REMOVE_USER_DETAILS = 'checkout/REMOVE_USER_DETAILS';

export const storeCheckoutDetails = details => ({
  type: STORE_CHECKOUT_DETAILS,
  payload: details
});

export const storeCarrierBags = required => ({
  type: STORE_CARRIER_BAGS,
  payload: required
});

export const setUserDetails = ({ name, email }) => ({
  type: SET_USER_DETAILS,
  payload: { name, email }
});

export const removeUserDetails = ({ name, email }) => ({
  type: REMOVE_USER_DETAILS,
  payload: { name, email }
});
