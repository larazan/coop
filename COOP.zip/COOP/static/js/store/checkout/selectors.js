import { get } from 'lodash/fp';

const getCheckout = state => state.checkout;

export const getCheckoutDetails = state => ({
  ...getCheckout(state)
});

export const getCarrierBags = state => get(['carrierBags'], getCheckout(state)) === true;
