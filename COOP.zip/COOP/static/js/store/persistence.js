import { throttle } from 'lodash/fp';
import { saveState } from './localStorage';
import { getStateForPersistence } from './selectors';

export function addStorePersistence(store) {
  const unsubscribe = store.subscribe(
    throttle(1000, () => {
      const state = getStateForPersistence(store.getState());
      saveState(state);
    })
  );

  return { ...store, unsubscribe };
}
