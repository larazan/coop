/* eslint-disable no-console */
/* eslint-disable class-methods-use-this */

import { compact } from 'lodash/fp';
import { Logger } from './logger';

const log = (logger, prefix, message, data) => {
  logger(`${prefix}: ${message}`, ...compact([data]));
};

export class LocalLogger extends Logger {
  critical(message, data = null) {
    log(console.error, 'critical', message, data);
  }

  error(message, data = null) {
    log(console.error, 'error', message, data);
  }

  warning(message, data = null) {
    log(console.error, 'warning', message, data);
  }

  info(message, data = null) {
    log(console.log, 'info', message, data);
  }

  debug(message, data = null) {
    log(console.log, 'debug', message, data);
  }
}

export const build = () => new LocalLogger();
