import { applyMiddleware, combineReducers, compose, createStore as createReduxStore } from 'redux';
import createSagaMiddleware from 'redux-saga';
import { all } from 'redux-saga/effects';
import account from './account';
import addresses, { addressesSaga } from './addresses';
import { gtmMiddlewareFactory } from './analytics';
import analyticsSaga from './analytics/operations';
import api from './api/reducer';
import basket, { basketSaga } from './basket';
import categories, { categoriesSaga } from './categories';
import checkout from './checkout/reducer';
import cms, { cmsSaga } from './cms';
import complete, { completeSaga } from './complete';
import { loadState } from './localStorage';
import { buildLogger } from './logger';
import messages from './messages';
import order, { orderSaga } from './order';
import paymentSaga from './payment/operations';
import { addStorePersistence } from './persistence';
import products, { productsSaga } from './products';
import search, { searchSaga } from './search';
import shoppingIn, { shoppingInSaga } from './shoppingIn';
import slots, { slotSaga } from './slots';
import stores, { storesSaga } from './stores';
import ui from './ui';

export const rootReducer = combineReducers({
  account,
  addresses,
  api,
  basket,
  categories,
  checkout,
  cms,
  complete,
  messages,
  order,
  products,
  search,
  shoppingIn,
  slots,
  stores,
  ui
});

/* eslint-disable  no-underscore-dangle */
// Middleware and enhancers
const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

export function* allSagas() {
  yield all([
    addressesSaga(),
    analyticsSaga(),
    basketSaga(),
    categoriesSaga(),
    cmsSaga(),
    completeSaga(),
    orderSaga(),
    paymentSaga(),
    productsSaga(),
    searchSaga(),
    shoppingInSaga(),
    slotSaga(),
    storesSaga()
  ]);
}

const persistedState = loadState();

const middleware = () => {
  const logger = buildLogger();

  return createSagaMiddleware({ context: { logger } });
};

const createStore = (initialState = persistedState) => {
  const sagaMiddleware = middleware();
  const gtmMiddleware = gtmMiddlewareFactory();

  let store = createReduxStore(
    rootReducer,
    initialState, // this takes precedence over individual reducer initial state
    composeEnhancers(applyMiddleware(sagaMiddleware, gtmMiddleware))
  );

  store = addStorePersistence(store);

  sagaMiddleware.run(allSagas);
  return store;
};

export default createStore;
