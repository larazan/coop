import { isEmpty, map } from 'lodash/fp';
import { call, debounce, put, race, select, take, takeEvery } from 'redux-saga/effects';
import { apis } from '../../api/dgApi';
import { getCheckoutDetails } from '../checkout/selectors';
import { getOrderBasketId, getOrderSlotSelector, getOrderVoucherCode } from '../order/selectors';
import { getBasketItems } from '../products/selectors';
import { PRODUCTS_IN_STORE_RANGE, STORE_ID_CHANGED } from '../shoppingIn/actions';
import { getCurrentStore, getCurrentStoreExtId } from '../stores/selectors';
import { showCheckAvailability, HIDE_CHECK_AVAILABILITY } from '../ui/actions';
import {
  APPLY_VOUCHER_CODE,
  CHANGE_BASKET_QUANTITY,
  CHECK_CAN_ADD_TO_BASKET,
  EVALUATE_MEMBER_DISCOUNT,
  FETCH_BASKET_PRODUCTS_SUCCESS,
  removeUnavailableBasketItems,
  REMOVE_MEMBER_DISCOUNT,
  REMOVE_VOUCHER_CODE,
  unavailableInStore,
  updateBasketFailure,
  updateBasketSuccess,
  updateBasketTotal
} from './actions';
import { distinctItemsInBasketCount } from './selectors';
import { unavailableProductsCurrentlyInBasket } from './selectors.shared';
import { checkCustomerLocationAndProductAvailability } from '../shoppingIn/operations';

export function* evaluateMemberDiscount({ payload: { membershipNumber: newMembershipNumber } }) {
  yield put(updateBasketTotal());

  const basketId = yield select(getOrderBasketId);
  const basketItems = yield select(getBasketItems());
  const slot = yield select(getOrderSlotSelector());
  const { membershipNumber: currentMembershipNumber } = yield select(getCheckoutDetails);
  const storeExternalId = yield select(getCurrentStoreExtId);

  if (newMembershipNumber !== currentMembershipNumber) {
    try {
      const { checkout, evaluate, order } = yield call(apis.basket.evaluate, {
        basketId,
        basketItems,
        membershipNumber: newMembershipNumber,
        slot,
        storeExternalId
      });

      // ! FIXME: is it necessary to hold basket totals in
      // ! order AND api.basket sections of state?
      // ! (that's why we have to put two actions here)
      yield put(updateBasketSuccess({ checkout, evaluate, order }));
    } catch (error) {
      // FIXME: add test to verify this behaviour
      yield put(updateBasketFailure());
    }
  }
}

export function* calculateBasketCost() {
  yield put(updateBasketTotal());

  const basketId = yield select(getOrderBasketId);
  const basketItems = yield select(getBasketItems());
  const { membershipNumber } = yield select(getCheckoutDetails);
  const slot = yield select(getOrderSlotSelector());
  const storeExternalId = yield select(getCurrentStoreExtId);

  try {
    const { checkout, evaluate, order } = yield call(apis.basket.evaluate, {
      basketId,
      basketItems,
      membershipNumber,
      slot,
      storeExternalId
    });

    yield put(updateBasketSuccess({ checkout, evaluate, order }));
  } catch (error) {
    // FIXME: add test to verify this behaviour
    yield put(updateBasketFailure());
  }
}

export function* isBasketAvailableWorker({ payload }) {
  yield race([
    call(checkCustomerLocationAndProductAvailability, payload),
    take(HIDE_CHECK_AVAILABILITY)
  ]);
}

export function* onStoreChange() {
  const basketCount = yield select(distinctItemsInBasketCount);

  if (!basketCount) {
    yield null;
  }

  function* removeUnavailableAndCalculateBasketCost(unavailable) {
    const store = yield select(getCurrentStore);
    const unavailableGtins = map('gtin', unavailable);
    yield put(removeUnavailableBasketItems({ unavailableGtins }));
    yield call(calculateBasketCost);
    yield put(unavailableInStore({ products: unavailable, unavailableIn: store.name }));
  }

  yield take(PRODUCTS_IN_STORE_RANGE);
  const unavailable = yield select(unavailableProductsCurrentlyInBasket);

  if (!isEmpty(unavailable)) {
    yield call(removeUnavailableAndCalculateBasketCost, unavailable);
    yield put(showCheckAvailability());
  }
}

export function* applyVoucherCodeWorker({ payload: { voucherCode } }) {
  yield put(updateBasketTotal());

  const basketItems = yield select(getBasketItems());
  const slot = yield select(getOrderSlotSelector());
  const { membershipNumber } = yield select(getCheckoutDetails);
  const storeExternalId = yield select(getCurrentStoreExtId);

  try {
    const { checkout, evaluate, order } = yield call(apis.basket.evaluateApplyVoucher, {
      basketItems,
      membershipNumber,
      slot,
      storeExternalId,
      voucherCode
    });

    // ! FIXME: is it necessary to hold basket totals in
    // ! order AND api.basket sections of state?
    // ! (that's why we have to put two actions here)
    yield put(updateBasketSuccess({ checkout, evaluate, order }));
  } catch (error) {
    // FIXME: add test to verify this behaviour
    yield put(updateBasketFailure());
  }
}

export function* removeVoucherCodeWorker() {
  yield put(updateBasketTotal());

  const basketId = yield select(getOrderBasketId);
  const basketItems = yield select(getBasketItems());
  const { membershipNumber } = yield select(getCheckoutDetails);
  const slot = yield select(getOrderSlotSelector());
  const storeExternalId = yield select(getCurrentStoreExtId);

  try {
    const { checkout, evaluate, order } = yield call(apis.basket.evaluateRemoveVoucher, {
      basketId,
      basketItems,
      membershipNumber,
      slot,
      storeExternalId
    });

    // ! FIXME: is it necessary to hold basket totals in
    // ! order AND api.basket sections of state?
    // ! (that's why we have to put two actions here)
    yield put(updateBasketSuccess({ checkout, evaluate, order }));
  } catch (error) {
    // FIXME: add test to verify this behaviour
    yield put(updateBasketFailure());
  }
}

export function* changeBasketQuantity() {
  const currentVoucher = yield select(getOrderVoucherCode);

  if (currentVoucher) {
    yield call(removeVoucherCodeWorker);
  } else {
    yield call(calculateBasketCost);
  }
}

function* basketSaga() {
  yield takeEvery(CHECK_CAN_ADD_TO_BASKET, isBasketAvailableWorker);
  yield debounce(500, CHANGE_BASKET_QUANTITY, changeBasketQuantity);
  yield takeEvery(FETCH_BASKET_PRODUCTS_SUCCESS, calculateBasketCost);
  yield takeEvery(EVALUATE_MEMBER_DISCOUNT, evaluateMemberDiscount);
  yield takeEvery(REMOVE_MEMBER_DISCOUNT, calculateBasketCost);
  yield takeEvery(APPLY_VOUCHER_CODE, applyVoucherCodeWorker);
  yield takeEvery(REMOVE_VOUCHER_CODE, removeVoucherCodeWorker);
  yield takeEvery(STORE_ID_CHANGED, onStoreChange);
}

export default basketSaga;
