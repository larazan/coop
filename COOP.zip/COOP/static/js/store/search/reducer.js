import { map, get } from 'lodash/fp';
import * as actions from './actions';
import {
  FETCH_SEARCH_PRODUCTS_SUCCESS,
  FETCH_MORE_SEARCH_PRODUCTS_SUCCESS
} from '../products/actions';

export const initialState = {
  isFetching: false,
  categories: [],
  predictions: [],
  products: [],
  relatedTerms: [],
  errors: [],
  term: ''
};

export const storeProductsMatchingSearch = (state, { payload }) => {
  return { ...state, products: map('id', payload.items) };
};

export const storeMoreProductsMatchingSearch = (state, { payload }) => {
  return { ...state, products: [...state.products, ...map('id', payload.items)] };
};

const searchReducer = (state = initialState, action) => {
  switch (action.type) {
    case actions.SEARCH_REQUEST:
      return { ...state, term: action.payload.term };

    case actions.SEARCH_REQUEST_STARTED:
      return { ...state, isFetching: true };

    case actions.SEARCH_SUCCESS: {
      const ids = map(get('id'));
      return {
        ...state,
        predictions: action.payload.products,
        categories: ids(action.payload.categories),
        relatedTerms: action.payload.relatedTerms,
        isFetching: false
      };
    }
    case actions.SEARCH_FAILURE:
      return {
        ...state,
        errors: action.payload.errors,
        isFetching: false
      };

    case actions.SEARCH_CLEAR:
      return initialState;

    case FETCH_SEARCH_PRODUCTS_SUCCESS:
      return storeProductsMatchingSearch(state, action);
    case FETCH_MORE_SEARCH_PRODUCTS_SUCCESS:
      return storeMoreProductsMatchingSearch(state, action);
    default:
      return state;
  }
};

export default searchReducer;
