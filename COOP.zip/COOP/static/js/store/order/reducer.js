import { FULFILMENT_TYPE_COLLECTION, FULFILMENT_TYPE_DELIVERY } from '../../constants';
import { CLEAR_VOUCHER_ERROR, UPDATE_BASKET_SUCCESS } from '../basket/actions';
import { RESET_APP_STATE } from '../complete/actions';
import { CLEAR_EXPIRED_SLOT, CONFIRM_SLOT } from '../slots/actions';
import {
  SELECT_ADDRESS_SUCCESS,
  SELECT_COLLECTION_STORE,
  SELECT_DELIVERY_STORE,
  SWITCH_FULFILMENT_TYPE
} from './actions';
import { TRY_NEW_POSTCODE } from '../addresses/actions';

export const initialState = {
  address: null,
  basketId: '00000000-0000-0000-0000-000000000000',
  fulfilmentType: null,
  discount: 0,
  errorVoucher: null,
  slot: null,
  staffDiscount: 0,
  storeId: null,
  subtotal: 0,
  total: 0,
  voucherCode: null,
  voucherDiscount: 0
};

const switchFulfilmentType = (state, type) => ({
  ...state,
  address: null,
  fulfilmentType: type,
  slot: null
});

const selectAddressSuccess = (state, address) => ({
  ...state,
  address,
  fulfilmentType: FULFILMENT_TYPE_DELIVERY
});

const selectCollectionStore = (state, { id, name }) => ({
  ...state,
  storeId: id,
  address: {
    displayName: name
  },
  fulfilmentType: FULFILMENT_TYPE_COLLECTION
});

const selectDeliveryStore = (state, { id }) => ({
  ...state,
  storeId: id,
  fulfilmentType: FULFILMENT_TYPE_DELIVERY
});

const clearVoucherError = state => ({
  ...state,
  errorVoucher: null
});

const updateBasketSuccess = (state, { order }) => ({
  ...state,
  ...order
});

const orderReducer = (state = initialState, action) => {
  switch (action.type) {
    case CONFIRM_SLOT:
      return { ...state, slot: action.payload.id };
    case CLEAR_EXPIRED_SLOT:
      return { ...state, slot: null };
    case SWITCH_FULFILMENT_TYPE:
      return switchFulfilmentType(state, action.payload);
    case SELECT_ADDRESS_SUCCESS:
      return selectAddressSuccess(state, action.payload);
    case UPDATE_BASKET_SUCCESS:
      return updateBasketSuccess(state, action.payload);
    case RESET_APP_STATE:
      return initialState;
    case SELECT_COLLECTION_STORE:
      return selectCollectionStore(state, action.payload);
    case SELECT_DELIVERY_STORE:
      return selectDeliveryStore(state, action.payload);
    case CLEAR_VOUCHER_ERROR:
      return clearVoucherError(state);
    case TRY_NEW_POSTCODE:
      return { ...state, fulfilmentType: null, storeId: null };
    default:
      return state;
  }
};

export default orderReducer;
