import { getOr, head } from 'lodash/fp';
import { isFetchingFor } from '../shared';

export const isFetching = state => isFetchingFor('shoppingIn', state);

const getShoppingIn = state => state.shoppingIn;

export const getPostcode = state => getShoppingIn(state).postcode;

export const getError = state => getShoppingIn(state).error;

export const getCoordinates = state => getShoppingIn(state).coordinates;

export const getDeliveryStore = state => {
  const { deliveryStores } = getShoppingIn(state);
  return head(deliveryStores) || null;
};

export const getCollectionStore = state => {
  const { collectionStores } = getShoppingIn(state);
  return head(collectionStores) || null;
};

export const getCollectionName = state => {
  const store = getCollectionStore(state);
  return getOr(null, 'name', store);
};

export const getDefaultStoreId = state => {
  const deliveryStore = getDeliveryStore(state);
  return deliveryStore ? deliveryStore.id : null;
};
