import messagesReducer from './reducer';
import * as messagesActions from './actions';
import * as messagesSelectors from './selectors';

export { messagesActions, messagesSelectors };

export default messagesReducer;
