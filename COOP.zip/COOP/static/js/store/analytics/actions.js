export const DETAIL_VIEW = 'analytics/DETAIL_VIEW';
export const analyticsProductView = product => ({
  type: DETAIL_VIEW,
  payload: { product }
});

export const PURCHASE = 'analytics/PURCHASE';
export const analyticsPurchase = payload => ({
  type: PURCHASE,
  payload
});

// "checkout funnel" analytics
export const PAGE_VIEW_CHECKOUT_FUNNEL = 'analytics/PAGE_VIEW_CHECKOUT_FUNNEL';
export const analyticsCheckoutFunnel = ({ products, step, revenue }) => ({
  type: PAGE_VIEW_CHECKOUT_FUNNEL,
  payload: { products, step, revenue }
});
