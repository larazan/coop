export const DISMISS_COOKIE_BANNER = 'ui/DISMISS_COOKIE_BANNER';
export const SHOW_CHECK_AVAILABILITY = 'ui/SHOW_CHECK_AVAILABILITY';
export const HIDE_CHECK_AVAILABILITY = 'ui/HIDE_CHECK_AVAILABILITY';

export const dismissCookieBanner = () => ({
  type: DISMISS_COOKIE_BANNER
});

export const showCheckAvailability = () => ({
  type: SHOW_CHECK_AVAILABILITY
});

export const hideCheckAvailability = () => ({
  type: HIDE_CHECK_AVAILABILITY
});
