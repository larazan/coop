import { call, put, takeLatest } from 'redux-saga/effects';
import { apis } from '../../api/dgApi';
import { logErrorFrom } from '../../utils/logError';
import { refreshSlotsFailure, refreshSlotsSuccess, REFRESH_SLOTS } from './actions';

function* refreshSlotsWorker({ payload: { storeId, coordinates } }) {
  try {
    // TODO should we make this retryable?
    const res = yield call(apis.slot.getSlots, { storeId, coordinates });

    yield put(refreshSlotsSuccess(res));
  } catch (error) {
    logErrorFrom('refresh-slots', error);
    yield put(refreshSlotsFailure());
  }
}

function* slotSaga() {
  yield takeLatest(REFRESH_SLOTS, refreshSlotsWorker);
}

export default slotSaga;
