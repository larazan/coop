export const getApi = state => state.api;
