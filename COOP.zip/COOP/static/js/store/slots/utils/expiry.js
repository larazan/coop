import { parseISO, differenceInHours } from 'date-fns';

export const MINIMUM_TIME_TO_SLOT_START_IN_HOURS = 1;

export const hasExpired = ({ slot, now = new Date() }) => {
  const { date, startsAt } = slot;

  const slotTime = parseISO(`${date}T${startsAt}`);
  const hours = differenceInHours(slotTime, now);

  return hours < MINIMUM_TIME_TO_SLOT_START_IN_HOURS;
};
