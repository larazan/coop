import { compact, join, map, pipe } from 'lodash/fp';
import { categoryById } from '../../categories/selectors';

export const categoriesLabel = (state, categoryIds) => {
  const getNames = ids => {
    return map(id => {
      const category = categoryById(state, id);
      return category ? category.name : null;
    }, ids);
  };

  return pipe(getNames, compact, join('/'))(categoryIds);
};

export function productsWithCategoryLabel({ products, categories }) {
  return products.map(p => {
    return {
      ...p,
      category: categoriesLabel({ categories }, p.parentCategories)
    };
  });
}
