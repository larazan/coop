export const GET_STORE_DETAILS = 'stores/GET_STORE_DETAILS';
export const GET_STORE_DETAILS_SUCCESS = 'stores/GET_STORE_DETAILS_SUCCESS';

export const getStoreDetails = id => ({
  type: GET_STORE_DETAILS,
  payload: { id }
});

export const getStoreDetailsSuccess = payload => ({
  type: GET_STORE_DETAILS_SUCCESS,
  payload
});
