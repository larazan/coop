import { GET_STORE_DETAILS_SUCCESS } from './actions';

export const initialState = {};

export function getStoreDetailsSuccess(state, { id, extId, name, postcode }) {
  return {
    ...state,
    [id]: { id, extId, name, postcode }
  };
}

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_STORE_DETAILS_SUCCESS:
      return getStoreDetailsSuccess(state, action.payload);
    default:
      return state;
  }
};

export default reducer;
