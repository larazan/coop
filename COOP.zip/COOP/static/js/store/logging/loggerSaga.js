import { getContext } from 'redux-saga/effects';

function* getLogger() {
  const logger = yield getContext('logger');
  return logger;
}

export function* critical(message, data = null) {
  const logger = yield getLogger();
  logger.critical(message, data);
}

export function* error(message, data = null) {
  const logger = yield getLogger();
  logger.error(message, data);
}

export function* warning(message, data = null) {
  const logger = yield getLogger();
  logger.warning(message, data);
}

export function* info(message, data = null) {
  const logger = yield getLogger();
  logger.info(message, data);
}

export function* debug(message, data = null) {
  const logger = yield getLogger();
  logger.debug(message, data);
}
