export const now = () => new Date(Date.now());
