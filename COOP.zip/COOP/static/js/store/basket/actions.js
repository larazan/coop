export const FETCH_BASKET_PRODUCTS = 'basket/FETCH_BASKET_PRODUCTS';
export const FETCH_BASKET_PRODUCTS_SUCCESS = 'basket/FETCH_BASKET_PRODUCTS_SUCCESS';
export const CHANGE_BASKET_QUANTITY = 'basket/CHANGE_BASKET_QUANTITY';
export const CHECK_CAN_ADD_TO_BASKET = 'basket/CHECK_CAN_ADD_TO_BASKET';
export const UPDATE_BASKET_REQUEST = 'basket/UPDATE_BASKET_REQUEST';
export const UPDATE_BASKET_SUCCESS = 'basket/UPDATE_BASKET_SUCCESS';
export const UPDATE_BASKET_FAILURE = 'basket/UPDATE_BASKET_FAILURE';
export const UNAVAILABLE_IN_NEW_STORE = 'basket/UNAVAILABLE_IN_NEW_STORE';
export const REMOVE_UNAVAILABLE_BASKET_ITEMS = 'basket/REMOVE_UNAVAILABLE_BASKET_ITEMS';

export const STORE_SIGNED_IN_BASKET = 'basket/STORE_SIGNED_IN_BASKET';

export const EVALUATE_MEMBER_DISCOUNT = 'basket/EVALUATE_MEMBER_DISCOUNT';
export const REMOVE_MEMBER_DISCOUNT = 'basket/REMOVE_MEMBER_DISCOUNT';

export const APPLY_VOUCHER_CODE = 'basket/APPLY_VOUCHER_CODE';
export const REMOVE_VOUCHER_CODE = 'basket/REMOVE_VOUCHER_CODE';
export const CLEAR_VOUCHER_ERROR = 'basket/CLEAR_VOUCHER_ERROR';

export const updateBasketTotal = () => ({
  type: UPDATE_BASKET_REQUEST
});

// ! FIXME: rename in form memberDiscountOperation
export const evaluateMemberDiscount = ({ membershipNumber }) => ({
  type: EVALUATE_MEMBER_DISCOUNT,
  payload: { membershipNumber }
});

export const removeMemberDiscount = () => ({
  type: REMOVE_MEMBER_DISCOUNT
});

export const applyVoucherCode = ({ voucherCode }) => ({
  type: APPLY_VOUCHER_CODE,
  payload: { voucherCode }
});

export const removeVoucherCode = () => ({
  type: REMOVE_VOUCHER_CODE
});

export const clearVoucherError = () => ({
  type: CLEAR_VOUCHER_ERROR
});

export const changeBasketQuantity = (gtin, quantity) => ({
  type: CHANGE_BASKET_QUANTITY,
  payload: { gtin, quantity }
});

export const checkCanAdd = (gtin, quantity) => ({
  type: CHECK_CAN_ADD_TO_BASKET,
  payload: { gtin, quantity }
});

export const loadBasketProducts = gtins => ({
  type: FETCH_BASKET_PRODUCTS,
  payload: {
    gtins
  }
});

export const loadBasketProductsSuccess = ({ products: items }) => ({
  type: FETCH_BASKET_PRODUCTS_SUCCESS,
  payload: { items }
});

export const updateBasketSuccess = ({ checkout, evaluate, order }) => ({
  type: UPDATE_BASKET_SUCCESS,
  payload: { checkout, evaluate, order }
});

export const updateBasketFailure = () => ({ type: UPDATE_BASKET_FAILURE });

export const unavailableInStore = ({ products, unavailableIn }) => ({
  type: UNAVAILABLE_IN_NEW_STORE,
  payload: { products, unavailableIn }
});

export const removeUnavailableBasketItems = ({ unavailableGtins }) => ({
  type: REMOVE_UNAVAILABLE_BASKET_ITEMS,
  payload: { unavailableGtins }
});
