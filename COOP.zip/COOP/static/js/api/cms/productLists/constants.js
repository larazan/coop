export const listTypes = Object.freeze({
  basket: 'basket'
});
