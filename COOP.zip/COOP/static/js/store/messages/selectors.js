import { getOr, isEmpty, last, omit } from 'lodash/fp';
import { createSelector } from 'reselect';
import { SEVERITY } from './errors';

// FIXME refactor: omitting byPathname until we can refactor messages away from the root
export const getMessages = state => omit('byPathname', state.messages);

const getMessageWithSeverity = (messages, severity) =>
  isEmpty(messages) ? null : last(Object.values(messages).filter(msg => msg.severity === severity));

export const getNonMajorMessageSelector = () =>
  createSelector([getMessages], messages =>
    isEmpty(messages)
      ? null
      : last(
          Object.values(messages).filter(
            ({ severity }) => severity === SEVERITY.INFO || severity === SEVERITY.MINOR
          )
        )
  );

export const getInfoMessageSelector = () =>
  createSelector([getMessages], messages => getMessageWithSeverity(messages, SEVERITY.INFO));

export const getMinorErrorSelector = () =>
  createSelector([getMessages], messages => getMessageWithSeverity(messages, SEVERITY.MINOR));

export const getMajorErrorSelector = () =>
  createSelector([getMessages], messages => getMessageWithSeverity(messages, SEVERITY.MAJOR));

// by-pathname
export const getMessageByPathname = pathname => state =>
  getOr(null, `byPathname.${pathname}`, state.messages);
