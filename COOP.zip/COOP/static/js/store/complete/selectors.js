import { get, isEmpty } from 'lodash/fp';

export const getComplete = state => state.complete;

// ! this is shaky until we can query DG directly for an order's status
export const isComplete = state => {
  const { basket, order } = getComplete(state);

  return !isEmpty(basket) && get('isOrderPlaced', order);
};

export const getCompleteBasket = state => getComplete(state).basket;

export const getCompleteOffers = state => getComplete(state).offers;

export const getCompleteOrder = state => getComplete(state).order;

export const getCompleteOrderConfirmedPrice = state => getCompleteOrder(state).confirmedPrice;
