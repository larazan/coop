import { differenceInMinutes, parseISO } from 'date-fns';
import getOr from 'lodash/fp/getOr';
import { getOrderAddressDisplayName } from '../../order/selectors';
import { getApi } from './shared';

export const getOrder = state => getApi(state).order;

export const getCheckoutId = state => getOrder(state).checkoutId;

export const getOrderNumber = state => getOrder(state).orderNumber;

export const getCheckoutSessionExpired = (state, currentTime = new Date()) => {
  const { createdAt } = getOrder(state);
  const diff = differenceInMinutes(currentTime, parseISO(createdAt));

  return diff >= 30;
};

export const getApiCompleteOrder = state => {
  const {
    orderNumber,
    visibleId,
    createdAt,
    confirmedPrice,
    customerEmail,
    totalBreakdown,
    isOrderPlaced
  } = getOrder(state);

  const address = getOrderAddressDisplayName(state);

  return {
    orderNumber,
    visibleId,
    createdAt,
    confirmedPrice,
    customerEmail,
    address,
    totalBreakdown,
    isOrderPlaced
  };
};

export const getConfirmedPrice = state => getOr(null, 'confirmedPrice', getOrder(state));
