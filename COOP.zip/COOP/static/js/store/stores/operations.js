import { call, put, takeEvery } from 'redux-saga/effects';
import { apis } from '../../api/dgApi';
import { logError } from '../../utils/logError';
import { SELECT_COLLECTION_STORE } from '../order/actions';
import { getStoreDetailsSuccess, GET_STORE_DETAILS } from './actions';

function* getStoreDetails(id) {
  try {
    return yield call(apis.stores.get, { storeId: id });
  } catch (error) {
    logError(error);
    throw new Error(error);
  }
}

export function* getStoreDetailsWorker({ payload: { id } }) {
  try {
    const response = yield getStoreDetails(id);

    yield put(getStoreDetailsSuccess(response));
  } catch (error) {
    logError(error);
    // TODO what to do in this case? make this action retryable?
  }
}

function* storesSaga() {
  yield takeEvery(GET_STORE_DETAILS, getStoreDetailsWorker);
  yield takeEvery(SELECT_COLLECTION_STORE, getStoreDetailsWorker);
}

export default storesSaga;
