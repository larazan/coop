import reducer from './reducer';
import * as productActions from './actions';
import * as productSelectors from './selectors';
import productsSaga from './operations';

export { productActions, productSelectors, productsSaga };

export default reducer;
