import { TRY_NEW_POSTCODE } from '../addresses/actions';
import { DISMISS_COOKIE_BANNER, HIDE_CHECK_AVAILABILITY, SHOW_CHECK_AVAILABILITY } from './actions';

const initialState = {
  cookieBannerDismissed: false,
  setLocation: false
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case DISMISS_COOKIE_BANNER:
      return { ...state, cookieBannerDismissed: true };
    case SHOW_CHECK_AVAILABILITY:
      return { ...state, setLocation: true };
    case HIDE_CHECK_AVAILABILITY:
    case TRY_NEW_POSTCODE:
      return { ...state, setLocation: false };
    default:
      return state;
  }
};

export default reducer;
