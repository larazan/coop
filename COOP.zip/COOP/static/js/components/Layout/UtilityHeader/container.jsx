import { withRouter } from 'react-router';
import UtilityHeader from '.';

export default withRouter(UtilityHeader);
