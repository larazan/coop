import { isEmpty } from 'lodash/fp';
import { call, put, select, take, takeLatest } from 'redux-saga/effects';
import { apis } from '../../api/dgApi';
import { postcodeNotInServiceArea } from '../addresses/actions';
import {
  errors,
  getLocationInfoFor,
  isInServiceArea,
  PostcodeError
} from '../addresses/operations.components';
import { changeBasketQuantity, unavailableInStore } from '../basket/actions';
import { fetchCategories } from '../categories/operations';
import { productsMatchingGtins } from '../products/selectors';
import { getStoreDetails, GET_STORE_DETAILS_SUCCESS } from '../stores/actions';
import { getCurrentStore } from '../stores/selectors';
import { hideCheckAvailability, showCheckAvailability } from '../ui/actions';
import {
  productsInStoreRange,
  selectPostcodeError,
  selectPostcodeSuccess,
  SELECT_POSTCODE,
  STORE_ID_CHANGED
} from './actions';
import { getPostcode } from './selectors';

function* selectPostcodeWorker({ payload }) {
  const { postcode } = payload;

  try {
    const { coordinates, collections, deliveries, storeId } = yield call(
      getLocationInfoFor,
      postcode
    );

    yield call(isInServiceArea, { collections, deliveries });

    yield put(getStoreDetails(storeId));

    yield put(
      selectPostcodeSuccess({
        postcode,
        coordinates,
        collectionStores: collections,
        deliveryStores: deliveries
      })
    );
  } catch (e) {
    if (e instanceof PostcodeError) {
      if (e.message === errors.notInServiceArea) {
        yield put(postcodeNotInServiceArea(e.message));
      } else {
        yield put(selectPostcodeError(e.message));
      }
    } else {
      yield put(selectPostcodeError(errors.unhandled));
    }
  }
}

export function* checkCustomerLocationAndProductAvailability({ gtin, quantity }) {
  const [product] = yield select(productsMatchingGtins(gtin));
  yield put(showCheckAvailability());

  // now block until the user has a store
  yield take(GET_STORE_DETAILS_SUCCESS);

  const postcode = yield select(getPostcode);

  // check availability of products in new store before adding to basket
  const { id } = yield select(getCurrentStore);

  const { unavailable } = yield call(apis.products.checkAvailability, {
    gtins: gtin,
    storeId: id
  });

  if (!isEmpty(unavailable)) {
    yield put(unavailableInStore({ products: product, unavailableIn: postcode }));
  } else {
    yield put(changeBasketQuantity(gtin, quantity));
    yield put(hideCheckAvailability());
  }
}

export function* storeIdChangedWorker({ payload: { storeId } }) {
  const products = yield call(apis.products.range, { storeId });

  yield put(productsInStoreRange({ products, storeId }));

  yield call(fetchCategories);
}

function* shoppingInSaga() {
  yield takeLatest(STORE_ID_CHANGED, storeIdChangedWorker);
  yield takeLatest(SELECT_POSTCODE, selectPostcodeWorker);
}

export default shoppingInSaga;
