import { REFRESH_SLOTS, REFRESH_SLOTS_FAILURE, REFRESH_SLOTS_SUCCESS } from './actions';

export const initialState = {
  isFetching: false,
  collection: {},
  delivery: {}
};

const refreshSlotsSuccess = (state, { collection, delivery }) => ({
  ...state,
  collection,
  delivery,
  isFetching: false
});

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case REFRESH_SLOTS:
      return { ...state, isFetching: true };
    case REFRESH_SLOTS_SUCCESS:
      return refreshSlotsSuccess(state, action.payload);
    case REFRESH_SLOTS_FAILURE:
      return { ...state, isFetching: false };
    default:
      return state;
  }
};

export default reducer;
