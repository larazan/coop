import reducer from './reducer';
import * as addressesActions from './actions';
import addressesSaga from './operations';

export { addressesActions, addressesSaga };

export default reducer;
