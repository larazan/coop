import { omit } from 'lodash/fp';
import { RESET_APP_STATE } from '../complete/actions';
import { HIDE_CHECK_AVAILABILITY } from '../ui/actions';
import {
  CHANGE_BASKET_QUANTITY,
  FETCH_BASKET_PRODUCTS,
  FETCH_BASKET_PRODUCTS_SUCCESS,
  REMOVE_UNAVAILABLE_BASKET_ITEMS,
  UNAVAILABLE_IN_NEW_STORE,
  UPDATE_BASKET_FAILURE,
  UPDATE_BASKET_REQUEST,
  UPDATE_BASKET_SUCCESS
} from './actions';

export const initialState = {
  items: {},
  isFetching: false,
  unavailable: [],
  unavailableIn: null
};

const isAlreadyInBasket = (id, basketItems) => basketItems[id];

const replaceItemInBasket = (basketItems, item) => {
  if (item.quantity === 0) {
    return omit(item.gtin, basketItems);
  }
  return { ...basketItems, [item.gtin]: item };
};

const changeBasketItemQuantity = (basketItems, item) => {
  if (!isAlreadyInBasket(item.gtin, basketItems) && item.quantity > 0) {
    return { ...basketItems, [item.gtin]: item };
  }

  return replaceItemInBasket(basketItems, item);
};

const storeUnavailableProducts = (state, { products, unavailableIn }) => {
  return { ...state, unavailable: state.unavailable.concat(products), unavailableIn };
};

const clearUnavailableProducts = state => ({ ...state, unavailable: [], unavailableIn: null });

export const removeUnavailableBasketItems = (state, { unavailableGtins }) => {
  return {
    ...state,
    items: omit(unavailableGtins, state.items)
  };
};

const basketReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_BASKET_PRODUCTS:
    case UPDATE_BASKET_REQUEST: {
      return { ...state, isFetching: true };
    }
    case FETCH_BASKET_PRODUCTS_SUCCESS: {
      return { ...state, isFetching: false };
    }
    case UPDATE_BASKET_SUCCESS: {
      return { ...state, isFetching: false, updated: true };
    }
    case UPDATE_BASKET_FAILURE: {
      return { ...state, isFetching: false, updated: false };
    }
    case CHANGE_BASKET_QUANTITY: {
      const updatedBasketItems = changeBasketItemQuantity(state.items, action.payload);
      return { ...state, items: updatedBasketItems };
    }
    case UNAVAILABLE_IN_NEW_STORE: {
      return storeUnavailableProducts(state, action.payload);
    }
    case REMOVE_UNAVAILABLE_BASKET_ITEMS: {
      return removeUnavailableBasketItems(state, action.payload);
    }
    case HIDE_CHECK_AVAILABILITY: {
      return clearUnavailableProducts(state);
    }
    case RESET_APP_STATE: {
      return initialState;
    }
    default:
      return state;
  }
};

export default basketReducer;
