import { call, put, putResolve, select, takeEvery, takeLatest } from 'redux-saga/effects';
import { apis } from '../../api/dgApi';
import { logError } from '../../utils/logError';
import { FETCH_BASKET_PRODUCTS, loadBasketProductsSuccess } from '../basket/actions';
import { categoriesActions, categoriesSelectors } from '../categories';
import { ERROR_FETCHING_PRODUCTS, ERROR_FETCHING_PRODUCT_DETAILS } from '../messages/errors';
import { getStoreId } from '../order/selectors';
import {
  FETCH_INITIAL_PRODUCTS,
  FETCH_MORE_PRODUCTS,
  FETCH_MORE_SEARCH_PRODUCTS,
  FETCH_PRODUCT,
  FETCH_PRODUCTS_BY_GTIN,
  FETCH_PRODUCTS_CANCEL,
  FETCH_SEARCH_PRODUCTS,
  loadMoreProductsSuccess,
  loadMoreSearchMatchesSuccess,
  loadProductByIdSuccess,
  loadProductsFailure,
  loadProductsSuccess,
  loadSearchMatchesSuccess
} from './actions';
import { getNextPageForProductFetch, productCountByKey } from './selectors';

function getNextPage(key) {
  return select(s => getNextPageForProductFetch(s, key));
}

function* fetchProductsWorker({
  apiFn: fn,
  payload,
  successAction,
  errorMsg = ERROR_FETCHING_PRODUCTS
} = {}) {
  const storeId = yield select(getStoreId);

  try {
    const res = yield call(fn, {
      ...payload,
      storeId
    });
    yield put(successAction(res));
  } catch (error) {
    logError(error);
    yield put(loadProductsFailure(errorMsg));
  }
}

function* fetchInitialProductsOfCategory(action) {
  const {
    payload: { parentCategoryId }
  } = action;
  const alreadyFetched = yield select(state => productCountByKey(state, parentCategoryId));

  if (alreadyFetched) {
    yield put({ type: FETCH_PRODUCTS_CANCEL });
    return;
  }

  const noCategoriesLoaded = yield select(categoriesSelectors.noCategoriesLoaded());

  if (noCategoriesLoaded) {
    yield putResolve(categoriesActions.loadCategories());
  }

  const nextPage = yield getNextPage(parentCategoryId);
  yield fetchProductsWorker({
    apiFn: apis.products.getByCategory,
    payload: {
      parentCategoryId,
      nextPage
    },
    successAction: loadProductsSuccess
  });
}

function* fetchProductsByGtin({ successAction }, { payload }) {
  yield fetchProductsWorker({
    apiFn: apis.products.getByGtin,
    payload,
    successAction
  });
}

function* fetchProductInformation({ payload: { productId } }) {
  yield fetchProductsWorker({
    apiFn: apis.products.getById,
    payload: {
      productId
    },
    successAction: loadProductByIdSuccess,
    errorMsg: ERROR_FETCHING_PRODUCT_DETAILS
  });
}

function* fetchMoreProducts({ payload: { parentCategoryId } }) {
  const nextPage = yield getNextPage(parentCategoryId);

  yield fetchProductsWorker({
    apiFn: apis.products.getByCategory,
    payload: {
      parentCategoryId,
      nextPage
    },
    successAction: loadMoreProductsSuccess
  });
}

function* fetchProductsMatchingSearch({ successAction }, { payload: { searchTerm } }) {
  const nextPage = yield getNextPage(searchTerm);

  yield fetchProductsWorker({
    apiFn: apis.products.getBySearchTerm,
    payload: {
      nextPage,
      searchTerm
    },
    successAction
  });
}

function* productsSaga() {
  yield takeEvery(FETCH_SEARCH_PRODUCTS, fetchProductsMatchingSearch, {
    successAction: loadSearchMatchesSuccess
  });
  yield takeEvery(FETCH_MORE_SEARCH_PRODUCTS, fetchProductsMatchingSearch, {
    successAction: loadMoreSearchMatchesSuccess
  });
  yield takeEvery(FETCH_INITIAL_PRODUCTS, fetchInitialProductsOfCategory);
  yield takeEvery(FETCH_BASKET_PRODUCTS, fetchProductsByGtin, {
    successAction: loadBasketProductsSuccess
  });
  yield takeEvery(FETCH_PRODUCTS_BY_GTIN, fetchProductsByGtin, {
    successAction: loadProductsSuccess
  });
  yield takeEvery(FETCH_MORE_PRODUCTS, fetchMoreProducts);
  yield takeLatest(FETCH_PRODUCT, fetchProductInformation);
}

export default productsSaga;
