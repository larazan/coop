export const ACCOUNT_SIGN_IN = 'account/SIGN_IN';
export const ACCOUNT_SIGN_IN_AUTO = 'account/SIGN_IN_AUTO';
export const ACCOUNT_SIGN_IN_SUCCESS = 'account/SIGN_IN_SUCCESS';
export const ACCOUNT_SIGN_IN_FAILURE = 'account/SIGN_IN_FAILURE';

export const signIn = () => ({
  type: ACCOUNT_SIGN_IN
});

export const signInAuto = () => ({
  type: ACCOUNT_SIGN_IN_AUTO
});

export const signInSuccess = () => ({
  type: ACCOUNT_SIGN_IN_SUCCESS
});

export const signInFailure = () => ({
  type: ACCOUNT_SIGN_IN_FAILURE
});
