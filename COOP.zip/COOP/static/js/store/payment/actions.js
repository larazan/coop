export const PAYMENT_CHECKOUT_SESSION_EXPIRED = 'payment/CHECKOUT_SESSION_EXPIRED';
export const PAYMENT_RESET_STATE = 'payment/PAYMENT_RESET_STATE';
export const PAYMENT_SLOT_EXPIRED = 'payment/PAYMENT_SLOT_EXPIRED';

export const PAYMENT_SUBMIT_FORM = 'payment/PAYMENT_SUBMIT_FORM';

export const FINALIZE_ORDER = 'payment/FINALIZE_ORDER';
export const FINALIZE_ORDER_SUCCESS = 'payment/FINALIZE_ORDER_SUCCESS';
export const FINALIZE_ORDER_FAILURE = 'payment/FINALIZE_ORDER_FAILURE';

export const submitPaymentForm = () => ({ type: PAYMENT_SUBMIT_FORM });

export const checkoutSessionExpired = () => ({
  type: PAYMENT_CHECKOUT_SESSION_EXPIRED
});

export const resetPaymentState = () => ({
  type: PAYMENT_RESET_STATE
});

export const finalizeOrder = () => ({
  type: FINALIZE_ORDER
});

export const finalizeOrderSuccess = () => ({
  type: FINALIZE_ORDER_SUCCESS
});

export const finalizeOrderFailure = () => ({
  type: FINALIZE_ORDER_FAILURE
});

export const slotExpiredBeforePayment = () => ({
  type: PAYMENT_SLOT_EXPIRED
});
