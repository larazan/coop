import { call, put, select, takeLatest } from 'redux-saga/effects';
import { apis } from '../../api/dgApi';
import { SLOT_FULL } from '../../api/utils/getErrorFromApiResponse';
import { getBasketEvaluate } from '../api/selectors/basket';
import { getCheckoutDetails } from '../checkout/selectors';
import { ERROR_PLACE_ORDER_MISC } from '../messages/errors';
import { clearExpiredSlot } from '../slots/actions';
import { hasExpired } from '../slots/utils/expiry';
import { getCurrentStore } from '../stores/selectors';
import { error as logError } from '../logging/loggerSaga';

import {
  placeOrderFailure,
  placeOrderFailureSlot,
  placeOrderSuccess,
  PLACE_ORDER_REQUEST
} from './actions';
import { getOrderAddress, isCollection as isCollectionSelector } from './selectors';
import { build } from './utils/buildOrderPayload';

export function* rejectOrderForSlot() {
  yield put(placeOrderFailureSlot());
  yield put(clearExpiredSlot());
}

export function* placeOrder({ payload: { slot, products } }) {
  if (hasExpired({ slot })) {
    yield rejectOrderForSlot();
    return;
  }

  const address = yield select(getOrderAddress);
  const checkoutDetails = yield select(getCheckoutDetails);
  const evaluate = yield select(getBasketEvaluate);
  const isCollection = yield select(isCollectionSelector);
  const store = yield select(getCurrentStore);

  const payload = yield call(build, {
    address,
    checkoutDetails,
    evaluate,
    isCollection,
    products,
    slot,
    store
  });

  try {
    const response = yield call(apis.ordersCreate, { order: payload });

    yield put(placeOrderSuccess(response));
  } catch ({ error }) {
    yield logError('create order failure', { error, store });

    // FIXME: should we be rejecting promises with an actual JS error, not an object?
    // eslint seems to think so
    if (error.code === SLOT_FULL) {
      yield rejectOrderForSlot();
    } else {
      yield put(placeOrderFailure(ERROR_PLACE_ORDER_MISC));
    }
  }
}

function* orderSaga() {
  yield takeLatest(PLACE_ORDER_REQUEST, placeOrder);
}

export default orderSaga;
