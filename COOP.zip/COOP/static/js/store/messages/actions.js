import { v4 as uuidv4 } from 'uuid';

export const SIGN_IN_SUCCESS_MESSAGE = 'messages/SIGN_IN_SUCCESS_MESSAGE';

export const REMOVE_MESSAGE = 'messages/REMOVE_MESSAGE';
export const REMOVE_MESSAGE_BY_ID = 'messages/REMOVE_MESSAGE_BY_ID';

export const SET_PATHNAME_MESSAGE = 'messages/SET_PATHNAME_MESSAGE';
export const REMOVE_PATHNAME_MESSAGE = 'messages/REMOVE_PATHNAME_MESSAGES';

export const addMessage = (type, message, data) => ({
  type,
  payload: {
    message: {
      id: uuidv4(),
      type,
      ...message
    },
    data
  }
});

export const addMessageOnly = (type, message) => addMessage(type, message, null);

export const removeMessage = severity => ({
  type: REMOVE_MESSAGE,
  payload: {
    severity
  }
});

export const removeMessageById = id => ({
  type: REMOVE_MESSAGE_BY_ID,
  payload: {
    id
  }
});

export const setPathnameMessage = (pathname, message) => ({
  type: SET_PATHNAME_MESSAGE,
  payload: { pathname, message }
});

export const removePathnameMessage = pathname => ({
  type: REMOVE_PATHNAME_MESSAGE,
  payload: { pathname }
});
