export const SEARCH_REQUEST = 'search/REQUEST';
export const SEARCH_REQUEST_STARTED = 'search/REQUEST_STARTED';
export const SEARCH_SUCCESS = 'search/SUCCESS';
export const SEARCH_FAILURE = 'search/FAILURE';
export const SEARCH_CLEAR = 'search/CLEAR';

export const search = term => ({ type: SEARCH_REQUEST, payload: { term } });
export const searchStartRequest = () => ({ type: SEARCH_REQUEST_STARTED });
export const searchFailure = errors => ({ type: SEARCH_FAILURE, payload: { errors } });

export const searchSuccess = results => ({
  type: SEARCH_SUCCESS,
  payload: {
    products: results.products,
    categories: results.categories,
    relatedTerms: results.related_terms
  }
});

export const clearSearch = () => ({ type: SEARCH_CLEAR });
