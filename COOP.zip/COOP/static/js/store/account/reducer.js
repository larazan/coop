import {
  ACCOUNT_SIGN_IN,
  ACCOUNT_SIGN_IN_AUTO,
  ACCOUNT_SIGN_IN_FAILURE,
  ACCOUNT_SIGN_IN_SUCCESS
} from './actions';

// TODO could maybe re-use these in other reducers...
const fetching = state => ({
  ...state,
  isFetching: true
});

const notFetching = state => ({
  ...state,
  isFetching: false
});

// move this to its own file or export it from here?
const states = {
  signedOut: 'signed-out',

  signInClick: {
    start: 'sign-in',
    success: 'signed-in'
  },

  signInAuto: {
    start: 'sign-in-auto',
    success: 'signed-in-auto'
  }
};

export const SIGNED_IN_CLICK = states.signInClick.success;
export const SIGNED_IN_AUTO = states.signInAuto.success;

export const initialState = notFetching({
  status: states.signedOut
});

const signIn = state =>
  fetching({
    ...state,
    status: states.signInClick.start
  });

const autoSignIn = state =>
  fetching({
    ...state,
    status: states.signInAuto.start
  });

const signInSuccess = ({ status, ...state }) =>
  notFetching({
    ...state,
    status: status === states.signInAuto.start ? SIGNED_IN_AUTO : SIGNED_IN_CLICK
  });

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case ACCOUNT_SIGN_IN:
      return signIn(state);
    case ACCOUNT_SIGN_IN_AUTO:
      return autoSignIn(state);
    case ACCOUNT_SIGN_IN_SUCCESS:
      return signInSuccess(state);
    case ACCOUNT_SIGN_IN_FAILURE:
      return notFetching(state);
    default:
      return state;
  }
};

export default reducer;
