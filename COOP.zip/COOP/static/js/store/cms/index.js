import cmsSaga from './operations';
import reducer from './reducer';

export { cmsSaga };

export default reducer;
