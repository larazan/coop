import { compact, map } from 'lodash/fp';
import { createSelector } from 'reselect';
import { getCategories } from '../categories/selectors';
import { isFetchingFor } from '../shared';

export const isFetching = state => isFetchingFor('search', state);

const getSearch = state => state.search;

export const getCategoryMatches = () =>
  createSelector([getSearch, getCategories], (search, categories) => ({
    categories: compact(map(cId => categories.items[cId], search.categories))
  }));

export const getPredictions = state => getSearch(state).predictions;
export const getSearchProductsIds = state => getSearch(state).products;
