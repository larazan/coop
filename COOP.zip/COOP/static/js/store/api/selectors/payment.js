import { PAYMENT_FAILED, PAYMENT_SUCCESSFUL } from '../reducer';
import { getCheckoutSessionExpired, getOrder } from './order';
import { getApi } from './shared';

export const getPayment = state => getApi(state).payment;

export const getPaymentStatus = state => {
  const { isFinalized, isSubmitted, status } = getPayment(state);
  return { isFinalized, isSubmitted, status };
};

export const isPaymentSuccessful = state => {
  const { isFinalized, status } = getPaymentStatus(state);

  return isFinalized && status === PAYMENT_SUCCESSFUL;
};

export const hasFailedPayment = state => {
  const { isFinalized, status } = getPaymentStatus(state);

  return isFinalized && status === PAYMENT_FAILED;
};

const hasCheckoutUrl = state => !!getOrder(state).checkoutUrl;

export const shouldCheckPaymentStatus = (state, currentTime = new Date()) => {
  const isSessionExpired = getCheckoutSessionExpired(state, currentTime);
  const { isSubmitted } = getPaymentStatus(state);

  return isSubmitted && hasCheckoutUrl(state) && !isSessionExpired;
};

export const canAccessPaymentPage = (state, currentTime = new Date()) => {
  return hasCheckoutUrl(state) && !getCheckoutSessionExpired(state, currentTime);
};
