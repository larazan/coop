import { addMessage } from '../messages/actions';

// single product details
export const FETCH_PRODUCT = 'products/FETCH_PRODUCT';
export const FETCH_PRODUCT_SUCCESS = 'products/FETCH_PRODUCT_SUCCESS';
export const FETCH_PRODUCT_FAILURE = 'products/FETCH_PRODUCT_FAILURE';

// products of category or matching search term
export const FETCH_INITIAL_PRODUCTS = `products/FETCH_PRODUCTS_INITIAL`;
export const FETCH_PRODUCTS_BY_GTIN = `products/FETCH_PRODUCTS_BY_GTIN`;
export const FETCH_MORE_PRODUCTS = 'products/FETCH_MORE_PRODUCTS';
export const FETCH_MORE_PRODUCTS_SUCCESS = 'products/FETCH_MORE_SUCCESS';

export const FETCH_PRODUCTS_SUCCESS = 'products/FETCH_PRODUCTS_SUCCESS';
export const FETCH_PRODUCTS_CANCEL = 'products/FETCH_PRODUCTS_CANCEL';
export const FETCH_PRODUCTS_FAILURE = 'products/FETCH_PRODUCTS_FAILURE';

export const FETCH_SEARCH_PRODUCTS = 'products/FETCH_SEARCH_PRODUCTS';
export const FETCH_SEARCH_PRODUCTS_SUCCESS = 'products/FETCH_SEARCH_PRODUCTS_SUCCESS';
export const FETCH_MORE_SEARCH_PRODUCTS = 'products/FETCH_MORE_SEARCH_PRODUCTS';
export const FETCH_MORE_SEARCH_PRODUCTS_SUCCESS = 'products/FETCH_MORE_SEARCH_PRODUCTS_SUCCESS';

export const loadInitialProducts = payload => ({ type: FETCH_INITIAL_PRODUCTS, payload });

export const loadProductsMatchingSearchTerm = searchTerm => ({
  type: FETCH_SEARCH_PRODUCTS,
  payload: searchTerm
});

export const loadMoreProducts = payload => ({ type: FETCH_MORE_PRODUCTS, payload });

export const loadMoreSearchMatches = payload => ({
  type: FETCH_MORE_SEARCH_PRODUCTS,
  payload
});

export const loadProductsSuccess = ({ products: items, pagination, parentCategoryId }) => ({
  type: FETCH_PRODUCTS_SUCCESS,
  payload: { items, pagination, parentCategoryId }
});

export const loadSearchMatchesSuccess = ({ products: items, pagination, searchTerm }) => ({
  type: FETCH_SEARCH_PRODUCTS_SUCCESS,
  payload: { items, pagination, searchTerm }
});

export const loadMoreProductsSuccess = ({ products: items, pagination, parentCategoryId }) => ({
  type: FETCH_MORE_PRODUCTS_SUCCESS,
  payload: { items, pagination, parentCategoryId }
});

export const loadMoreSearchMatchesSuccess = ({ products: items, pagination, searchTerm }) => ({
  type: FETCH_MORE_SEARCH_PRODUCTS_SUCCESS,
  payload: { items, pagination, searchTerm }
});

export const loadProductsFailure = error => addMessage(FETCH_PRODUCTS_FAILURE, error);

export const loadProductById = productId => ({ type: FETCH_PRODUCT, payload: { productId } });

export const loadProductByIdSuccess = product => ({
  type: FETCH_PRODUCT_SUCCESS,
  payload: product
});

// FIME: they want gtins, so give them gtins
export const loadProductsByGtin = gtins => ({
  type: FETCH_PRODUCTS_BY_GTIN,
  payload: { gtins }
});
