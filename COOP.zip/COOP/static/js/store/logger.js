import { getEnv, getEnvName } from '../utils/environment';
import { isRollbarLoggingFromLocalhostEnabled } from '../utils/featureFlag';
import { build as buildRollbar } from './logging/rollbar';
import { build as buildLocal } from './logging/local';

const isRollbarLoggingRequired = () => {
  const env = getEnv().NODE_ENV;
  if (env === 'development' && !isRollbarLoggingFromLocalhostEnabled()) {
    return false;
  }
  return true;
};

export const buildLogger = () => {
  if (isRollbarLoggingRequired()) {
    const { REACT_APP_LOGGING_KEY: accessToken } = getEnv();
    const environment = getEnvName();

    return buildRollbar({ accessToken, environment });
  }
  return buildLocal();
};
