import { isNil } from 'lodash/fp';
import { createSelector } from 'reselect';
import { isCollection as isCollectionType, STORE_ID } from '../../constants';
import { getMaxBasketSize } from '../../utils/environment';
import { isBasketMaxSizeEnabled } from '../../utils/featureFlag';
import {
  isBasketEmpty,
  meetsMinimumBasketValue,
  totalItemsInBasketCount
} from '../basket/selectors';
import { getBasketItems } from '../products/selectors';
import { getDefaultStoreId } from '../shoppingIn/selectors';
import { getMemoizedById } from '../slots/selectors';

// ! FIXME favour selector specificity over exporting the whole blob
export const getOrder = state => state.order;

export const getOrderStoreId = state => getOrder(state).storeId;
export const getStoreId = state => getOrderStoreId(state) || getDefaultStoreId(state) || STORE_ID;

export const getOrderSlotId = state => getOrder(state).slot;

export const getOrderVoucherCode = state => getOrder(state).voucherCode;
export const getOrderBasketId = state => getOrder(state).basketId;

const getSlots = state => state.slots;
export const getOrderSlotSelector = () =>
  createSelector([getOrder, getSlots], (order, slots) => {
    const slot = getMemoizedById(order.slot, slots);
    return slot || null;
  });

export const getOrderFulfilmentSelector = () =>
  createSelector([getOrderSlotSelector(), getOrder], (reservedSlot, order) => {
    return {
      reservedSlot,
      selectedAddress: order.address,
      fulfilmentType: order.fulfilmentType
    };
  });

export const getDeliveryType = state => getOrder(state).fulfilmentType;
export const isCollection = state => isCollectionType(getOrder(state).fulfilmentType);

export const basketItemsFormattedForOrder = () =>
  createSelector(getBasketItems(), items =>
    items.map(item => ({
      sku: item.sku,
      gtin: item.gtin,
      quantity: item.quantity,
      allow_replace: false,
      unit_price: {
        price: item.price,
        price_vat: item.price
      },
      row_price: {
        price: item.price,
        price_vat: item.price
      }
    }))
  );

export const getOrderAddress = state => {
  const { address } = getOrder(state);
  return address;
};

// FIXME this should be removed / moved to shopping-in
export const getOrderAddressDisplayName = state => {
  return getOrderAddress(state).displayName;
};

const isBasketSizeEligible = state => {
  const maxBasketSize = getMaxBasketSize();
  const basketSizeCheckDisabled = !isBasketMaxSizeEnabled();

  if (basketSizeCheckDisabled) {
    return true;
  }

  return totalItemsInBasketCount(state) <= maxBasketSize;
};

export const isEligibleForCheckout = state => {
  const { reservedSlot, selectedAddress } = getOrderFulfilmentSelector()(state);

  const hasSlot = !isNil(reservedSlot);
  const hasAddress = !isNil(selectedAddress);
  const basketHasItems = !isBasketEmpty(state);
  const basketIsSmallEnough = isBasketSizeEligible(state);
  const meetsMinimumValue = meetsMinimumBasketValue(state);

  return hasSlot && hasAddress && basketHasItems && basketIsSmallEnough && meetsMinimumValue;
};
