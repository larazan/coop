import { get, isEqual, omit } from 'lodash/fp';
import { isCollection } from '../../constants';
import { isMandatoryBagsEnabled } from '../../utils/featureFlag';
import { REMOVE_MEMBER_DISCOUNT, UPDATE_BASKET_SUCCESS } from '../basket/actions';
import { RESET_APP_STATE } from '../complete/actions';
import { SELECT_COLLECTION_STORE, SWITCH_FULFILMENT_TYPE } from '../order/actions';
import {
  REMOVE_USER_DETAILS,
  SET_USER_DETAILS,
  STORE_CARRIER_BAGS,
  STORE_CHECKOUT_DETAILS
} from './actions';

export const initialState = {
  fullName: '',
  email: '',
  membershipNumber: '',
  mobilePhone: '',
  messageToDriver: '',
  carrierBags: false
};

const storeCheckoutDetails = (
  state,
  { fullName, email, membershipNumber, mobilePhone, messageToDriver, carrierBags }
) => ({
  ...state,
  fullName,
  email,
  membershipNumber,
  mobilePhone,
  messageToDriver,
  carrierBags
});

const storeSwitchFulfilmentType = (state, type) => {
  if (isCollection(type)) {
    return {
      ...state,
      messageToDriver: '',
      carrierBags: true
    };
  }

  return {
    ...state,
    carrierBags: isMandatoryBagsEnabled()
  };
};

const storeCarrierBags = (state, required) => ({
  ...state,
  carrierBags: required
});

const updateBasketSuccess = (state, { checkout }) => {
  const membershipNumber = get('membershipNumber', checkout);
  return {
    ...state,
    membershipNumber
  };
};

const removeMembershipNumber = state => ({
  ...state,
  membershipNumber: initialState.membershipNumber
});

const withDetails = ({ state, name, email }) => ({
  ...state,
  fullName: name,
  email
});

// ignoring carrier-bags
const ignoreCbs = state => omit(['carrierBags'], state);

const setUserDetails = (state, { name, email }) => {
  if (isEqual(ignoreCbs(state), ignoreCbs(initialState))) {
    return withDetails({ state, name, email });
  }
  return state;
};

const removeUserDetails = (state, { name, email }) => {
  const current = withDetails({ state: initialState, name, email });

  if (isEqual(ignoreCbs(state), ignoreCbs(current))) {
    return {
      ...state,
      fullName: '',
      email: ''
    };
  }
  return state;
};

const reducer = (state = initialState, action) => {
  const { type, payload } = action;

  switch (type) {
    case STORE_CHECKOUT_DETAILS:
      return storeCheckoutDetails(state, payload);
    case SWITCH_FULFILMENT_TYPE:
      return storeSwitchFulfilmentType(state, payload);
    case STORE_CARRIER_BAGS:
      return storeCarrierBags(state, payload);
    case SELECT_COLLECTION_STORE:
      return storeCarrierBags(state, true);
    case UPDATE_BASKET_SUCCESS:
      return updateBasketSuccess(state, action.payload);
    case REMOVE_MEMBER_DISCOUNT:
      return removeMembershipNumber(state);
    case SET_USER_DETAILS:
      return setUserDetails(state, action.payload);
    case REMOVE_USER_DETAILS:
      return removeUserDetails(state, action.payload);
    case RESET_APP_STATE:
      return initialState;
    default:
      return state;
  }
};

export default reducer;
