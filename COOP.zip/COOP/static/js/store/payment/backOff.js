import { call, delay } from 'redux-saga/effects';
import { getRetryConfig } from './config';

function getDelay(numOfAttempts, initialDelay) {
  const base = 2;
  const power = numOfAttempts;
  const currentDelay = initialDelay * base ** power;

  return currentDelay;
}

// Based on https://github.com/coveooss/exponential-backoff
export function* backOff(fn, opts, logRetry) {
  const { maxRetries, initialDelay } = getRetryConfig();

  for (let i = 0; i < maxRetries; i += 1) {
    try {
      const response = yield call(fn, opts);
      return response;
    } catch (err) {
      if (i < maxRetries - 1) {
        yield logRetry(err);

        const current = getDelay(i, initialDelay);
        yield delay(current);
      }
    }
  }

  // failed after maxRetries
  throw new Error('Max attempts to determine payment status reached');
}
