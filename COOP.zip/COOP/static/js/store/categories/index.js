import reducer from './reducer';
import * as categoriesActions from './actions';
import * as categoriesSelectors from './selectors';
import categoriesSaga from './operations';

export { categoriesActions, categoriesSaga, categoriesSelectors };

export default reducer;
