import find from 'lodash/fp/find';

function getBasketQuantity(basketItems, gtin) {
  const basketItem = find(['gtin', gtin], basketItems);

  return basketItem ? basketItem.quantity : 0;
}

export default getBasketQuantity;
