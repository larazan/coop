import GoogleTagManager from '@redux-beacon/google-tag-manager';
import { createMiddleware } from 'redux-beacon';
import { getEventsMap } from './eventsMap';

export const gtmMiddlewareFactory = () => {
  const eventsMap = getEventsMap();
  const gtm = GoogleTagManager();
  const gtmMiddleware = createMiddleware(eventsMap, gtm);

  return gtmMiddleware;
};
