export const SELECT_POSTCODE = 'shopping-in/SELECT_POSTCODE';
export const SELECT_POSTCODE_SUCCESS = 'shopping-in/SELECT_POSTCODE_SUCCESS';
export const SELECT_POSTCODE_ERROR = 'shopping-in/SELECT_POSTCODE_ERROR';
export const STORE_ID_CHANGED = 'shopping-in/STORE_ID_CHANGED';
export const PRODUCTS_IN_STORE_RANGE = 'shopping-in/PRODUCTS_IN_STORE_RANGE';

export const selectPostcode = postcode => ({
  type: SELECT_POSTCODE,
  payload: { postcode }
});

export const selectPostcodeSuccess = ({
  postcode,
  coordinates,
  collectionStores,
  deliveryStores
}) => ({
  type: SELECT_POSTCODE_SUCCESS,
  payload: {
    postcode,
    coordinates,
    collectionStores,
    deliveryStores
  }
});

export const selectPostcodeError = error => ({
  type: SELECT_POSTCODE_ERROR,
  payload: { error }
});

export const storeIdChanged = ({ storeId }) => ({
  type: STORE_ID_CHANGED,
  payload: { storeId }
});

export const productsInStoreRange = ({ products }) => ({
  type: PRODUCTS_IN_STORE_RANGE,
  payload: { products }
});
