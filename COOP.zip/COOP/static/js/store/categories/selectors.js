import { getOr, filter, isEmpty, map, pipe, sortBy } from 'lodash/fp';
import { createSelector } from 'reselect';
import { isFetchingFor } from '../shared';

export const getCategories = state => state.categories;
export const isFetching = state => isFetchingFor('categories', state);

export const getSelectedCategory = state => getCategories(state).selected;

const getCategoryItems = state => {
  return getCategories(state).items;
};

const isParentCategory = c => getOr([], 'subcategories', c).length > 0;

export function noCategoriesLoaded() {
  return createSelector([getCategoryItems], categories => isEmpty(categories));
}

const displayCategory = category => ({
  id: category.id,
  name: category.name,
  order: category.order
});

const getSubcategories = (state, category) => {
  if (!isParentCategory(category)) {
    return [];
  }

  return pipe(
    map(id => {
      return displayCategory(getCategoryItems(state)[id]);
    }),
    sortBy('order')
  )(category.subcategories);
};

export const categoryById = (state, id) => {
  const category = getCategoryItems(state)[id];

  if (!category) {
    return null;
  }

  return {
    ...displayCategory(category),
    subcategories: getSubcategories(state, category)
  };
};

export function rootCategories(state) {
  const categories = getCategoryItems(state);
  const parentCategoriesOnly = filter(c => c.subcategories.length);
  const sorted = sortBy('order');
  const withSubCategories = map(c => ({
    ...displayCategory(c),
    subcategories: getSubcategories(state, c)
  }));

  return pipe(parentCategoriesOnly, sorted, withSubCategories)(categories);
}
