/* eslint-disable no-unused-vars */
/* eslint-disable class-methods-use-this */

export class Logger {
  critical(message, data = null) {
    throw new Error('You have to implement the method critical!');
  }

  error(message, data = null) {
    throw new Error('You have to implement the method error!');
  }

  warning(message, data = null) {
    throw new Error('You have to implement the method warning!');
  }

  info(message, data = null) {
    throw new Error('You have to implement the method info!');
  }

  debug(message, data = null) {
    throw new Error('You have to implement the method debug!');
  }
}
