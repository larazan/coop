import { call, put, takeLatest } from 'redux-saga/effects';
import { apis } from '../../api/dgApi';
import {
  ERROR_ADDRESS_POSTCODE_INLINE_VALIDATION_FAIL,
  ERROR_ADDRESS_POSTCODE_LOOKUP_FAIL,
  ERROR_ADDRESS_POSTCODE_LOOKUP_NO_RESULTS,
  ERROR_ADDRESS_POSTCODE_LOOKUP_VALIDATION_FAIL
} from '../messages/errors';
import {
  selectAddressSuccess,
  selectDeliveryStore,
  SELECT_ADDRESS,
  switchToDelivery
} from '../order/actions';
import { confirmSlot } from '../slots/actions';
import { getStoreDetails } from '../stores/actions';
import {
  getCollectionStoresError,
  getCollectionStoresSuccess,
  getDeliveryAddressesOptionsSuccess,
  getDeliveryAddressesSuccess,
  GET_ADDRESS_LIST,
  GET_COLLECTION_STORES,
  postcodeNotInServiceArea,
  searchForAddressError,
  searchForAddressFailure,
  searchForAddressSuccess,
  SEARCH_FOR_ADDRESS
} from './actions';
import {
  errors,
  getLocationInfoFor,
  isInCollectionServiceArea,
  isInDeliveryServiceArea,
  PostcodeError
} from './operations.components';

function* getCollectionStoresWorker({ payload }) {
  const { postcode } = payload;

  try {
    const { coordinates, collections } = yield call(getLocationInfoFor, postcode);

    yield call(isInCollectionServiceArea, { collections });

    yield put(getCollectionStoresSuccess({ collectionStores: collections, coordinates, postcode }));
  } catch (e) {
    if (e instanceof PostcodeError) {
      if (e.message === errors.notInServiceArea) {
        yield put(postcodeNotInServiceArea());
      } else {
        yield put(getCollectionStoresError(e.message));
      }
    } else {
      yield put(getCollectionStoresError(errors.unhandled));
    }
  }
}

function* getAddressesForPostcode(postcode) {
  const { options } = yield call(apis.addressesList, { q: postcode });
  if (options.length === 0) {
    throw new PostcodeError(errors.postcodeUnknown);
  }
  return options;
}

function* getDeliveryAddressesWorker({ payload }) {
  const { postcode } = payload;

  try {
    const { coordinates, deliveries, storeId } = yield call(getLocationInfoFor, postcode);

    yield call(isInDeliveryServiceArea, { deliveries });

    const options = yield call(getAddressesForPostcode, postcode);

    yield put(getStoreDetails(storeId));

    yield put(
      getDeliveryAddressesSuccess({
        coordinates,
        deliveryStores: deliveries,
        options,
        postcode
      })
    );
  } catch (e) {
    if (e instanceof PostcodeError) {
      // nb. having to use the existing error states / notifications here for now 🤮
      if (e.message === errors.postcodeFormat) {
        yield put(searchForAddressError(ERROR_ADDRESS_POSTCODE_INLINE_VALIDATION_FAIL));
      } else if (e.message === errors.postcodeUnknown) {
        yield put(searchForAddressError(ERROR_ADDRESS_POSTCODE_LOOKUP_VALIDATION_FAIL));
      } else if (e.message === errors.notInServiceArea) {
        yield put(postcodeNotInServiceArea());
      } else {
        yield put(searchForAddressFailure(ERROR_ADDRESS_POSTCODE_LOOKUP_FAIL));
      }
    } else {
      yield put(searchForAddressFailure(ERROR_ADDRESS_POSTCODE_LOOKUP_FAIL));
    }
  }
}

export function* getAddressListFromPostcodeWorker(action) {
  try {
    const { options } = yield call(apis.addressesList, { q: action.payload.postcode });
    if (options.length > 0) {
      yield put(searchForAddressSuccess(options));
      return;
    }

    yield put(searchForAddressFailure(ERROR_ADDRESS_POSTCODE_LOOKUP_NO_RESULTS));
  } catch (error) {
    yield put(searchForAddressFailure(ERROR_ADDRESS_POSTCODE_LOOKUP_FAIL));
  }
}

export function* getFullAddressPartsWithLink({ payload }) {
  const { link, storeId, slot } = payload;

  try {
    // nb. will either return an address or further options to choose from
    const { address, options } = yield call(apis.address.getParts, { link });
    if (address) {
      yield put(switchToDelivery());

      yield put(selectDeliveryStore({ id: storeId }));
      yield put(selectAddressSuccess(address));

      // also confirm the slot if we have one
      if (slot) {
        const { slotId, date } = slot;
        yield put(confirmSlot(slotId, date));
      }
      return;
    }

    if (options) {
      yield put(getDeliveryAddressesOptionsSuccess(options));
      return;
    }

    yield put(searchForAddressFailure(ERROR_ADDRESS_POSTCODE_LOOKUP_NO_RESULTS));
  } catch (error) {
    yield put(searchForAddressFailure(ERROR_ADDRESS_POSTCODE_LOOKUP_FAIL));
  }
}

function* addressesSaga() {
  yield takeLatest(GET_COLLECTION_STORES, getCollectionStoresWorker);
  yield takeLatest(SEARCH_FOR_ADDRESS, getDeliveryAddressesWorker);

  yield takeLatest(SELECT_ADDRESS, getFullAddressPartsWithLink);
  yield takeLatest(GET_ADDRESS_LIST, getAddressListFromPostcodeWorker);
}

export default addressesSaga;
