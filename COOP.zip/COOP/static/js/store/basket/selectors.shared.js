import {
  compact,
  filter,
  flatMap,
  flow,
  getOr,
  isEmpty,
  map,
  take,
  uniq,
  values,
  without
} from 'lodash/fp';
import { listTypes } from '../../api/cms/productsLists/constants';
import { getMaxBasketSize } from '../../utils/environment';
import { isBasketMaxSizeEnabled } from '../../utils/featureFlag';
import { maxCrossSellItems } from '../cms/constants';
import { getProductListItems, relatedGtins } from '../cms/selectors';
import { getOrderStoreId } from '../order/selectors';
import { getUnavailableProducts } from '../products/selectors';
import { getDefaultStoreId, getPostcode } from '../shoppingIn/selectors';
import { getBasketItemGtins, totalItemsInBasketCount } from './selectors';

export const isMaxBasketSize = state => {
  const maxBasketSize = getMaxBasketSize();
  const basketSizeCheckDisabled = !isBasketMaxSizeEnabled();

  if (basketSizeCheckDisabled) {
    return false;
  }

  return totalItemsInBasketCount(state) >= maxBasketSize;
};

// before a customer can add anything to the basket, we need to know
// where they are shopping from to determine product range
export const isBasketAvailable = state => {
  const hasPostcode = !isEmpty(getPostcode(state));
  const isShoppingInDefaultStore = !isEmpty(getDefaultStoreId(state));
  const isShoppingInChosenStore = !isEmpty(getOrderStoreId(state));

  return hasPostcode || isShoppingInDefaultStore || isShoppingInChosenStore;
};

export const unavailableProductsCurrentlyInBasket = state => {
  const gtinsInBasket = getBasketItemGtins(state);
  const unavailable = values(getUnavailableProducts(state));
  const unavailableInBasket = filter(p => gtinsInBasket.includes(p.gtin), unavailable);

  return unavailableInBasket;
};

export const getBasketRelatedProducts = state => {
  const basketGtins = getBasketItemGtins(state);
  const relatedProductGtins = relatedGtins(state);

  return flow(
    map(x => relatedProductGtins[x]),
    flatMap(x => getOr([], 'related', x)),
    compact,
    uniq,
    without(basketGtins)
  )(basketGtins);
};

export const getDefaultRelatedProducts = state => getProductListItems(listTypes.basket)(state);

export const getCrossSellGtins = state => {
  const basketGtins = getBasketItemGtins(state);
  const allCrossSellGtins = [
    ...getBasketRelatedProducts(state),
    ...getDefaultRelatedProducts(state)
  ];

  // prettier-ignore
  return flow(
    uniq,
    without(basketGtins),
    take(maxCrossSellItems)
  )(allCrossSellGtins);
};
