import { put, select, takeLatest } from 'redux-saga/effects';
import { productsWithCategoryLabel } from '../analytics/shared';
import { getBasketPromotions } from '../api/selectors/basket';
import { getApiCompleteOrder } from '../api/selectors/order';
import { getPayment } from '../api/selectors/payment';
import { getCategories } from '../categories/selectors';
import { getDeliveryType, getOrderSlotSelector, getOrderVoucherCode } from '../order/selectors';
import { FINALIZE_ORDER_SUCCESS } from '../payment/actions';
import { getBasketItems } from '../products/selectors';
import { getCurrentStore } from '../stores/selectors';
import { resetAppState } from './actions';

function* completeWorker() {
  const basket = yield select(getBasketItems());
  const apiOrder = yield select(getApiCompleteOrder);
  const slot = yield select(getOrderSlotSelector());
  const fulfilmentType = yield select(getDeliveryType);
  const { paymentBrand } = yield select(getPayment);
  const { name: store } = yield select(getCurrentStore);
  const offers = yield select(getBasketPromotions);
  const categories = yield select(getCategories);
  const voucherCode = yield select(getOrderVoucherCode);

  const labelledProducts = productsWithCategoryLabel({ products: basket, categories });

  yield put(
    resetAppState({
      basket: labelledProducts,
      offers,
      order: { ...apiOrder, fulfilmentType, paymentBrand, store, voucherCode },
      slot
    })
  );
}

function* completeSaga() {
  yield takeLatest(FINALIZE_ORDER_SUCCESS, completeWorker);
}

export default completeSaga;
