import { find, omit, omitBy } from 'lodash/fp';
import { SEARCH_FOR_ADDRESS_FAILURE } from '../addresses/actions';
import { GET_CATEGORIES_FAILURE } from '../categories/actions';
import { RESET_APP_STATE } from '../complete/actions';
import { PLACE_ORDER_FAILURE } from '../order/actions';
import { FETCH_PRODUCTS_FAILURE, FETCH_PRODUCT_FAILURE } from '../products/actions';
import { CLEAR_EXPIRED_SLOT, CONFIRM_SLOT } from '../slots/actions';
import {
  REMOVE_MESSAGE,
  REMOVE_MESSAGE_BY_ID,
  REMOVE_PATHNAME_MESSAGE,
  SET_PATHNAME_MESSAGE,
  SIGN_IN_SUCCESS_MESSAGE
} from './actions';
import { EXPIRED_SLOT_NOTIFICATION } from './errors';

// FIXME danger here as currently messages are written to the root of this object!
//  need to refactor this for safety!
export const initialState = {
  byPathname: {}
};

const storeMessage = (state, message) => ({
  // FIXME refactor: stop storing messages in the root
  ...state,
  [message.id]: message
});

const filterMessageType = (state, message) => {
  if (message.type) {
    return !find(msg => msg.type === message.type, Object.values(state))
      ? storeMessage(state, message)
      : state;
  }

  return storeMessage(state, message);
};

const setPathnameMessage = (state, { pathname, message }) => ({
  ...state,
  byPathname: {
    ...state.byPathname,
    [pathname]: message
  }
});

const removePathnameMessage = (state, { pathname }) => ({
  ...state,
  byPathname: omit([pathname], state.byPathname)
});

const messagesReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_PRODUCT_FAILURE:
    case FETCH_PRODUCTS_FAILURE:
    case GET_CATEGORIES_FAILURE:
    case PLACE_ORDER_FAILURE:
    case SEARCH_FOR_ADDRESS_FAILURE:
    case SIGN_IN_SUCCESS_MESSAGE:
      return filterMessageType(state, action.payload.message);

    case REMOVE_MESSAGE:
      return omitBy(msg => msg.severity === action.payload.severity, state);

    case REMOVE_MESSAGE_BY_ID:
      return omitBy(msg => msg.id === action.payload.id, state);

    case CONFIRM_SLOT:
      return omit(CLEAR_EXPIRED_SLOT, state);

    case CLEAR_EXPIRED_SLOT:
      return {
        ...state,
        [CLEAR_EXPIRED_SLOT]: EXPIRED_SLOT_NOTIFICATION
      };

    case SET_PATHNAME_MESSAGE:
      return setPathnameMessage(state, action.payload);

    case REMOVE_PATHNAME_MESSAGE:
      return removePathnameMessage(state, action.payload);

    case RESET_APP_STATE:
      return initialState;
    default:
      return state;
  }
};

export default messagesReducer;
