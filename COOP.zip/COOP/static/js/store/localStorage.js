import { differenceInDays } from 'date-fns';
import { now } from '../utils/datetime';
import { getEnv } from '../utils/environment';

function isCacheStale(created) {
  const INVALIDATE_AFTER = 7;

  return differenceInDays(now(), created) > INVALIDATE_AFTER;
}

// In production, read this from an env var set to the commit hash of HEAD on master.
// In development, let developers manage cache invalidation manually lest they go insane.
export function getSchemaVersion() {
  if (process.env.NODE_ENV !== 'production') {
    return 'DEV_CACHE';
  }

  const { REACT_APP_VERSION } = getEnv();
  return REACT_APP_VERSION;
}

export const SCHEMA_VERSION = getSchemaVersion();
export const SCHEMA_VERSION_KEY = 'coop-schema-version';
export const CACHE_UPDATED_KEY = 'coop-cache-updated';
export const CACHE_STATE_KEY = 'coop-cache';

export const loadState = () => {
  let cachedState;
  try {
    const currentVersion = localStorage.getItem(SCHEMA_VERSION_KEY);
    const cacheCreatedDate = new Date(localStorage.getItem(CACHE_UPDATED_KEY));

    if (currentVersion === SCHEMA_VERSION && !isCacheStale(cacheCreatedDate)) {
      cachedState = localStorage.getItem(CACHE_STATE_KEY);
    } else {
      localStorage.removeItem(CACHE_STATE_KEY);
      localStorage.setItem(SCHEMA_VERSION_KEY, SCHEMA_VERSION);
    }
  } catch (error) {
    console.error(error.message); // eslint-disable-line
    return null;
  }

  return cachedState ? JSON.parse(cachedState) : {};
};

export const saveState = state => {
  try {
    localStorage.setItem(CACHE_STATE_KEY, JSON.stringify(state));
    localStorage.setItem(CACHE_UPDATED_KEY, now().toISOString());
  } catch (error) {
    console.error(error.message); // eslint-disable-line
  }
};
