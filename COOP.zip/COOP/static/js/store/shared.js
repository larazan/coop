import get from 'lodash/fp/get';

export const toBool = value => !!value;

export const isFetchingFor = (key, state) => toBool(get([key, 'isFetching'], state));
