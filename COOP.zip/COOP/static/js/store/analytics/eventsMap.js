import { isAnalyticsFunnelEnabled } from '../../utils/featureFlag';
import * as actions from './actions';
import { checkoutFunnel, purchase } from './ecommerce/order';
import { detailView } from './ecommerce/product';

const noop = () => null;

export const getEventsMap = () => {
  const { DETAIL_VIEW, PAGE_VIEW_CHECKOUT_FUNNEL, PURCHASE } = actions;

  return {
    [DETAIL_VIEW]: detailView,
    [PAGE_VIEW_CHECKOUT_FUNNEL]: isAnalyticsFunnelEnabled() ? checkoutFunnel : noop,
    [PURCHASE]: purchase
  };
};
