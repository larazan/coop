export const minutesToMilliseconds = minutes => minutes * 60000;
