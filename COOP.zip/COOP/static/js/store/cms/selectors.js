import { differenceInMinutes } from 'date-fns';
import { difference, find, get, isEqual, keys } from 'lodash/fp';
import { now } from '../../utils/datetime';
import { getBasketItemGtins } from '../basket/selectors';
import { cacheExpiryInMinutes } from './constants';

const getBannerByKey = key => state => {
  const item = find(each => isEqual(each.key, key), get('cms.banners.items', state));

  return item ? item.value : null;
};

export const getBannerByCategoryId = ({ categoryId }) => state => {
  const key = { categoryId };

  return getBannerByKey(key)(state);
};

export const getBannerByPage = ({ page }) => state => {
  const key = { page };

  return getBannerByKey(key)(state);
};

export const getBannerBySearchTerm = ({ searchTerm }) => state => {
  const key = { searchTerm };

  return getBannerByKey(key)(state);
};

export const requiresRefresh = cacheKey => state => {
  const cached = find(each => isEqual(each.key, cacheKey), get('cms.banners.cache', state));

  if (cached) {
    const diff = differenceInMinutes(new Date(), cached.lastModified);
    return diff >= cacheExpiryInMinutes;
  }
  return true;
};

export const relatedGtins = state => state.cms.relatedProducts;

const getProductsList = name => state => find({ name }, get('cms.productsLists', state));

export const getProductListItems = name => state => {
  const list = getProductsList(name)(state);
  return list ? list.items : [];
};

export const getBasketUnrelatedGtins = state => {
  const basketGtins = getBasketItemGtins(state);
  const relatedProductsGtins = relatedGtins(state);

  return difference(basketGtins, keys(relatedProductsGtins));
};

export const productsListRequiresRefresh = name => state => {
  const cached = getProductsList(name)(state);

  if (cached) {
    return (
      !cached.lastModified || differenceInMinutes(now(), cached.lastModified) > cacheExpiryInMinutes
    );
  }

  return true;
};

export const retrieveCampaign = state => state.cms.campaign;
