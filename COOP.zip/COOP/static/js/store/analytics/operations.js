import { find, map } from 'lodash/fp';
import { put, select, takeLatest } from 'redux-saga/effects';
import { RESET_APP_STATE } from '../complete/actions';
import { FETCH_PRODUCT_SUCCESS } from '../products/actions';
import { analyticsProductView, analyticsPurchase } from './actions';
import { categoriesLabel } from './shared';

function* productDetailView({ payload: product }) {
  const category = yield select(s => categoriesLabel(s, product.parentCategories));

  const { brand, name, price, sku: id } = product;

  yield put(
    analyticsProductView({
      brand,
      category,
      id,
      name,
      price,
      quantity: 1
    })
  );
}

export function reshapeOffers({ offers, id, price }) {
  const offer = find(o => find({ ean: id }, o.items), offers);

  if (offer) {
    const itemInOffer = find(['ean', id], offer.items);
    return {
      productPromo: offer.promoName,
      price: itemInOffer.promoPrice,
      productPromoValue: price - itemInOffer.promoPrice
    };
  }

  return {
    productPromo: '',
    price,
    productPromoValue: 0
  };
}

export function getProducts({ basket, offers }) {
  return map(product => {
    const { category, brand, name, price, sku: id, quantity } = product;
    const productOffer = reshapeOffers({ offers, id, price });

    return {
      category,
      brand,
      name,
      originalPrice: price,
      id,
      quantity,
      ...productOffer
    };
  }, basket);
}

export function getPurchaseEventLabel(basket) {
  return map('sku', basket).join('|');
}

function* purchase({ payload: { basket, offers, order, slot } }) {
  const {
    confirmedPrice,
    fulfilmentType,
    orderNumber,
    paymentBrand,
    store,
    totalBreakdown,
    voucherCode
  } = order;
  const offerNames = map('promoName', offers).join('|');
  const products = getProducts({ basket, offers });

  yield put(
    analyticsPurchase({
      deliveryCharges: slot.deliveryPrice,
      eventLabel: getPurchaseEventLabel(basket),
      id: orderNumber,
      offers: offerNames,
      orderDiscount: totalBreakdown.savings,
      paymentType: paymentBrand,
      products,
      revenue: confirmedPrice,
      store,
      transactionType: fulfilmentType,
      promoCode: voucherCode
    })
  );
}

function* analyticsSaga() {
  yield takeLatest(FETCH_PRODUCT_SUCCESS, productDetailView);
  yield takeLatest(RESET_APP_STATE, purchase);
}

export default analyticsSaga;
