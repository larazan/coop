import { RESET_APP_STATE } from './actions';

export const initialState = {
  basket: {},
  offers: {},
  order: {
    orderNumber: null,
    visibleId: null,
    createdAt: null,
    confirmedPrice: 0,
    totalBreakdown: null,
    isOrderPlaced: null
  },
  slot: {}
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case RESET_APP_STATE: {
      const { basket, offers, order, slot } = action.payload;

      return {
        basket,
        offers,
        order,
        slot
      };
    }
    default:
      return state;
  }
};

export default reducer;
