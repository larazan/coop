export const SUPPLIER_BANNER_BY_CATEGORY_ID = 'cms/SUPPLIER_BANNER_BY_CATEGORY_ID';
export const SUPPLIER_BANNER_BY_PAGE = 'cms/SUPPLIER_BANNER_BY_PAGE';
export const SUPPLIER_BANNER_BY_SEARCH_TERM = 'cms/SUPPLIER_BANNER_BY_SEARCH_TERM';

export const SUPPLIER_BANNER_ADD_ITEM = 'cms/SUPPLIER_BANNER_ADD_ITEM';
export const SUPPLIER_BANNER_REMOVE_ITEM = 'cms/SUPPLIER_BANNER_REMOVE_ITEM';

export const SUPPLIER_BANNER_ADD_TO_CACHE = 'cms/SUPPLIER_BANNER_ADD_TO_CACHE';

export const RELATED_PRODUCTS_GET_CROSS_SELL = 'cms/RELATED_PRODUCTS_GET_CROSS_SELL';
export const RELATED_PRODUCTS_ADD_ITEMS = 'cms/RELATED_PRODUCTS_ADD_ITEMS';
export const RELATED_PRODUCTS_PRUNE_CACHE = 'cms/RELATED_PRODUCTS_PRUNE_CACHE';

export const PRODUCTS_LISTS_ADD_ITEM = 'cms/PRODUCTS_LISTS_ADD_ITEM';

export const FETCH_CAMPAIGN_REQUEST = 'cms/FETCH_CAMPAIGN_REQUEST';
export const FETCH_CAMPAIGN_SUCCESS = 'cms/FETCH_CAMPAIGN_SUCCESS';

export const supplierBannerByCategoryId = ({ categoryId }) => ({
  type: SUPPLIER_BANNER_BY_CATEGORY_ID,
  payload: { categoryId }
});

export const supplierBannerByPage = ({ page }) => ({
  type: SUPPLIER_BANNER_BY_PAGE,
  payload: { page }
});

export const supplierBannerBySearchTerm = ({ searchTerm }) => ({
  type: SUPPLIER_BANNER_BY_SEARCH_TERM,
  payload: { searchTerm }
});

export const supplierBannerAddItem = ({
  key,
  imageAltText,
  images,
  linkUrl,
  termsAndConditions
}) => ({
  type: SUPPLIER_BANNER_ADD_ITEM,
  payload: {
    key,
    imageAltText,
    images,
    linkUrl,
    termsAndConditions
  }
});

export const supplierBannerRemoveItem = key => ({
  type: SUPPLIER_BANNER_REMOVE_ITEM,
  payload: { key }
});

export const supplierBannerAddToCache = cacheKey => ({
  type: SUPPLIER_BANNER_ADD_TO_CACHE,
  payload: { cacheKey }
});

export const relatedProductsGetCrossSell = type => ({
  type: RELATED_PRODUCTS_GET_CROSS_SELL,
  payload: { type }
});

export const relatedProductsAddItems = items => ({
  type: RELATED_PRODUCTS_ADD_ITEMS,
  payload: items
});

export const relatedProductsPruneCache = () => ({
  type: RELATED_PRODUCTS_PRUNE_CACHE
});

export const productsListsAddItem = list => ({
  type: PRODUCTS_LISTS_ADD_ITEM,
  payload: list
});

export const getCampaign = payload => ({
  type: FETCH_CAMPAIGN_REQUEST,
  payload
});

export const campaignSuccess = payload => ({
  type: FETCH_CAMPAIGN_SUCCESS,
  payload
});
